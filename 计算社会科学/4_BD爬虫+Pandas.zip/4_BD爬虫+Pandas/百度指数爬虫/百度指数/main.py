# -*- coding: utf-8 -*-
import time
import traceback
from config import CITY_CODE, PROVINCE_CODE, cookies
import pandas as pd
from baidu_index import get_search_index
import os

keywords_list = ['deepseek','南京','上海']

if __name__ == "__main__":

    for keyword in keywords_list:
        for province in list(PROVINCE_CODE.keys())[0:3]: #list(PROVINCE_CODE.keys())[0:3]  PROVINCE_CODE
            time.sleep(2)
            temps = []
            all = []
            try:

                baidu_index = get_search_index(keyword=keyword,
                                               start_date='2025-03-01',
                                               end_date='2025-03-10',
                                               cookies=cookies,
                                               area=PROVINCE_CODE[province]
                                               )
                # baidu_index = BaiduIndex(keyword, '2011-01-03', '2022-01-02', CITY_CODE[city])
                for index in baidu_index:
                    print(keyword, province, index)
                    all.append(index)

                for da in pd.DataFrame(all).groupby('date'):
                    t_dict = da[1]
                    jd = {}
                    for dai in t_dict.iterrows():
                        jd['province'] = province
                        jd['date'] = da[0]
                        jd['keyword'] = dai[1]['keyword']
                        jd[dai[1]['type']] = int(dai[1]['index'])
                        jd['province'] = province
                    temps.append(jd)
                pd.DataFrame(temps).to_csv('百度指数爬虫/百度指数/data/'+province+'_{0}_baidu_index.csv'.format(keyword), index=False, mode="a+", header=False)

            except:
                pd.DataFrame(temps).to_csv('百度指数爬虫/百度指数/data/'+province+'_{0}_baidu_index.csv'.format(keyword), index=False, mode="a+", header=False)
                print(keyword, province)
                traceback.print_exc()
