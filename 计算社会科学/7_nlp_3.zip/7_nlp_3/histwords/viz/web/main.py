import webserve

if __name__ == "__main__":
    webserve.main()

