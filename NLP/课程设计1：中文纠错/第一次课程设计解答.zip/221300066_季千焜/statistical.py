#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Statistical corrector for Chinese Text Correction task.
This module implements statistical methods for correcting errors in Chinese text.
"""

import re
import json
import torch
import numpy as np
from typing import Dict, List, Tuple, Any
from collections import Counter, defaultdict

from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from sklearn.metrics import fbeta_score, make_scorer #自定义f0.5


# Try to import optional dependencies
try:
    import jieba

    JIEBA_AVAILABLE = True
except ImportError:
    JIEBA_AVAILABLE = False
    print("Warning: jieba not available. Some features will be disabled.")

try:
    from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import accuracy_score

    # Import CRF if available
    try:
        import sklearn_crfsuite
        from sklearn_crfsuite import metrics

        CRF_AVAILABLE = True
    except ImportError:
        CRF_AVAILABLE = False
        print("Warning: sklearn_crfsuite not available. CRF features will be disabled.")

    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    CRF_AVAILABLE = False
    print("Warning: scikit-learn not available. Some features will be disabled.")





try:
    import torch
    from torch import nn
    from torch.utils.data import Dataset, DataLoader
    from transformers import BertModel, BertTokenizer
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("Warning: PyTorch/Transformers not available. BERT-LSTM features disabled.")

class StatisticalCorrector:
    """
    A statistical corrector for Chinese text.
    """

    def __init__(self, method='ngram'):
        """
        Initialize the statistical corrector.

        Args:
            method: The statistical method to use. Options: 'ngram', 'ml', 'crf', 'bert_lstm'.
        """
        self.method = method

        # N-gram language model
        self.unigram_counts = Counter()
        self.bigram_counts = Counter()
        self.trigram_counts = Counter()
        self.fourgram_counts = Counter()  # 4-gram for better context modeling

        # Character-level confusion matrix
        self.confusion_matrix = defaultdict(Counter)

        # Character error probabilities
        self.error_probs = defaultdict(float)

        # Phonetic and visual similarity matrices
        self.phonetic_similarity = defaultdict(dict)
        self.visual_similarity = defaultdict(dict)

        # Interpolation weights for different n-gram models
        self.lambda_1 = 0.1  # Weight for unigram
        self.lambda_2 = 0.3  # Weight for bigram
        self.lambda_3 = 0.4  # Weight for trigram
        self.lambda_4 = 0.2  # Weight for 4-gram


        # Machine learning models
        self.classifier = None
        self.ml_model = None
        self.error_probs = defaultdict(float)
        self.char_corrections = defaultdict(Counter)

        # BERT-LSTM相关参数
        self.bert_model = None
        self.lstm_model = None
        self.tokenizer = None
        self.char_vocab = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def train(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Train the statistical corrector using the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        if self.method == 'ngram':
            self._train_ngram_model(train_data)
        elif self.method == 'ml' and SKLEARN_AVAILABLE:
            self._train_ml_model(train_data)
        elif self.method == 'bert_lstm' and TORCH_AVAILABLE:
            self._train_bert_lstm_model(train_data)
        else:
            print(f"Warning: Method '{self.method}' not available. Falling back to n-gram model.")
            self._train_ngram_model(train_data)

    def _train_ngram_model(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Train an n-gram language model for text correction.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # TODO 完成ngram模型，可以使用其他的设计
        # Build n-gram language model from correct sentences
        for sample in train_data:
            # Use target (correct) text for building the language model
            text = sample['target']

            # Count unigrams (single characters)
            for char in text:
                self.unigram_counts[char] += 1
            for i in range(len(text) - 1):
                self.bigram_counts[text[i] + text[i + 1]] += 1
            for i in range(len(text) - 2):
                self.trigram_counts[text[i] + text[i + 1] + text[i + 2]] += 1
            for i in range(len(text) - 3):
                self.fourgram_counts[text[i] + text[i + 1] + text[i + 2] + text[i + 3]] += 1
            # TODO Count bigrams, trigrams, and 4-grams

            # Build confusion matrix from error pairs
            if sample['label'] == 1:  # Only for sentences with errors
                source = sample['source']
                target = sample['target']

                # For character substitution errors (when lengths are equal)
                if len(source) == len(target):
                    for i, (s_char, t_char) in enumerate(zip(source, target)):
                        if s_char != t_char:
                            # Record this confusion pair with context
                            left_context = source[max(0, i - 2): i]
                            right_context = source[i + 1: min(len(source), i + 3)]
                            context = left_context + '_' + right_context

                            self.confusion_matrix[(s_char, context)][t_char] += 1

                            # Also record general confusion without context
                            self.confusion_matrix[(s_char, '')][t_char] += 1

                            # Record error probability for this character
                            self.error_probs[s_char] += 1

                            # Record correction pair
                            self.char_corrections[s_char][t_char] += 1

        # Normalize error probabilities
        for char, count in self.error_probs.items():
            self.error_probs[char] = count / self.unigram_counts.get(char, 1)

        print(
            f"Trained n-gram model with {len(self.unigram_counts)} unigrams, "
            f"{len(self.bigram_counts)} bigrams, and {len(self.trigram_counts)} trigrams."
        )

    def _get_feature(self, source) -> Dict[str, float]:
        contexts = []
        window_size = 3
        for i in range(len(source)):
            start_idx = max(0, i - window_size)
            end_idx = min(len(source), i + window_size + 1)
            contexts.append(source[start_idx:end_idx])

        features = []

        for j in range(len(source)):
            char_features = {
                'char': ord(source[j]),
                'is_first': int(j == 0),
                'is_last': int(j == len(source) - 1),
                'is_digit': int(source[j].isdigit()),
                'is_punctuation': int(bool(re.match(r'[^\w\s]', source[j]))),
                'error_prob': self.error_probs[source[j]],
            }

            for k in range(1, 4):
                prev_idx = j - k
                if prev_idx >= 0:
                    char_features[f'prev_char_{k}'] = ord(source[prev_idx])
                else:
                    char_features[f'prev_char_{k}'] = 0

            for k in range(1, 4):
                next_idx = j + k
                if next_idx < len(source):
                    char_features[f'next_char_{k}'] = ord(source[next_idx])
                else:
                    char_features[f'next_char_{k}'] = 0
            features.append(char_features)
        return features

    def f05_eval(y_pred: np.ndarray, dtrain) -> Tuple[str, float]:
        # 将原始概率转换为二分类预测
        y_true = dtrain.get_label().astype(int)
        y_pred_bin = (y_pred > 0.5).astype(int)
        return 'f0.5', fbeta_score(y_true, y_pred_bin, beta=0.5)

    def _train_ml_model(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Train a machine learning model for text correction.

        Args:
            train_data: List of dictionaries containing the training data.
        """

        if not SKLEARN_AVAILABLE:
            print("Cannot train ML model: scikit-learn not available.")
            return

        self.total_char_num = defaultdict(float)
        for sample in train_data:
            source = sample['source']
            target = sample['target']
            if source != target and len(source) == len(target):
                for s, t in zip(source, target):
                    if s != t:
                        self.error_probs[s] += 1.0
                    self.total_char_num[s] += 1.0
        for char in self.error_probs.keys():
            if self.error_probs[char] >= 3.0:
                self.error_probs[char] /= self.total_char_num[char]
            else:
                self.error_probs[char] = 0.0
        print("Finish tfidf_vectorizer...")

        # TODO 完成ml方法实现，可选择不同的文本编码方式、不同的特征提取和不同的模型, 推荐先使用一个模型检测，再使用一个模型来纠错。
        # 可以先将训练数据分为训练集和验证集，分别检测两个模型的效果，并调参
        # 可以使用数据增强或者预训练的词向量来提高模型的准确性
        train_data = [sample for sample in train_data if len(sample['source']) == len(sample['target'])]
        train_set, val_set = train_test_split(train_data, test_size=0.2, random_state=42)
        X_train, y_train = [], []
        X_val, y_val = [], []
        for data in train_set:
            source = data['source']
            target = data['target']

            feature = self._get_feature(source)
            X_train.append(feature)
            y_train.append(list(target))
        for data in val_set:
            source = data['source']
            target = data['target']

            feature = self._get_feature(source)
            X_val.append(feature)
            y_val.append(list(target))
        print("Finish features...")
        confused_targets = defaultdict(int)
        for features, targets in zip(X_train + X_val, y_train + y_val):
            for feature, target in zip(features, targets):
                if feature['char'] != ord(target):
                    confused_targets[ord(target)] += 1
        self.error_detector = XGBClassifier(
            objective='binary:logistic',
            #eval_metric=f05_eval,  # 使用自定义 F0.5 评估
            scale_pos_weight=100,
            max_depth=11,
            learning_rate=0.05,
            reg_lambda=1.0,
            subsample=0.8,
            colsample_bytree=0.8,
            use_label_encoder=False,
            n_estimators=200
        )
        X_train_error = []
        y_train_error = []
        X_val_error = []
        y_val_error = []
        for features, targets in zip(X_train, y_train):
            for feature, target in zip(features, targets):
                if feature['char'] != ord(target) and confused_targets[ord(target)] <= 5:
                    continue
                X_train_error.append(list(feature.values()))
                y_train_error.append(int(feature['char'] != ord(target)))
        for features, targets in zip(X_val, y_train):
            for feature, target in zip(features, targets):
                if feature['char'] != ord(target) and confused_targets[ord(target)] <= 5:
                    continue
                X_val_error.append(list(feature.values()))
                y_val_error.append(int(feature['char'] != ord(target)))
        self.error_detector.fit(
            X_train_error,
            y_train_error,
            eval_set=[(X_val_error, y_val_error)],
            #early_stopping_rounds = 20,
            verbose = True
        )
        print("Error detection model trained successfully.")

        X_train_correction = []
        y_train_correction = []

        for features, targets in zip(X_train + X_val, y_train + y_val):
            for feature, target in zip(features, targets):
                if feature['char'] != ord(target) and confused_targets[ord(target)] >= 5:
                    X_train_correction.append(list(feature.values()))
                    y_train_correction.append(ord(target))
        self.label_encoder = LabelEncoder()
        y_train_encoded = self.label_encoder.fit_transform(y_train_correction)
        self.correction_predictor = XGBClassifier(
            objective='multi:softmax',
            num_class=len(self.label_encoder.classes_),
            booster='gblinear',
            reg_lambda=1.0,
            learning_rate=0.01,
            n_estimators=200,
            missing=-999,
            n_jobs=-1
        )
        self.correction_predictor.fit(
            X_train_correction,
            y_train_encoded
        )
        print("Correction prediction model trained successfully.")
        return

    def correct(self, text: str) -> str:
        """
        Apply statistical correction to the input text.

        Args:
            text: Input text to correct.

        Returns:
            Corrected text.
        """
        if self.method == 'ngram':
            return self._correct_with_ngram(text)
        elif self.method == 'ml' and SKLEARN_AVAILABLE:
            return self._correct_with_ml(text)
        elif self.method == 'bert_lstm' and TORCH_AVAILABLE:
            return self._correct_with_bert_lstm(text)
        else:
            return self._correct_with_ngram(text)

    def _correct_with_ngram(self, text: str) -> str:
        """
        Correct text using the n-gram language model.

        Args:
            text: Input text.

        Returns:
            Corrected text.
        """
        corrected_text = list(text)  # Convert to list for character-by-character editing

        # Check each character for potential errors
        for i in range(len(text)):
            char = text[i]

            # Skip characters with low error probability
            if self.error_probs.get(char, 0) < 0.01:
                continue

            # Get context for this character
            left_context = text[max(0, i - 2): i]
            right_context = text[i + 1: min(len(text), i + 3)]
            context = left_context + '_' + right_context

            # Check if we have seen this character in this context before
            if (char, context) in self.confusion_matrix and self.confusion_matrix[(char, context)]:
                # Get the most common correction for this character in this context
                correction = self.confusion_matrix[(char, context)].most_common(1)[0][0]
                corrected_text[i] = correction
                continue

            # If no specific context match, check general confusion matrix
            if (char, '') in self.confusion_matrix and self.confusion_matrix[(char, '')]:
                # Get the most common correction for this character
                correction = self.confusion_matrix[(char, '')].most_common(1)[0][0]
                # Only apply if it's a common error
                if self.confusion_matrix[(char, '')][correction] > 2:
                    corrected_text[i] = correction
                    continue

            # If no direct match, use interpolated n-gram model for characters with high error probability
            if self.error_probs.get(char, 0) >= 0.05 and i > 0 and i < len(text) - 1:
                # Generate candidate corrections
                candidates = set()

                # Add common characters as candidates
                candidates.update(list(self.unigram_counts.keys())[:300])  # Top 300 most common characters

                # Add correction candidates from confusion matrix
                for context_key in self.confusion_matrix:
                    if context_key[0] == char:
                        candidates.update(self.confusion_matrix[context_key].keys())

                # Try all candidates and find the one with highest probability
                best_score = -float('inf')
                best_char = char

                for candidate in candidates:
                    # Skip the original character
                    if candidate == char:
                        continue

                    # Calculate interpolated score using all n-gram models
                    score = 0

                    # Unigram probability (with smoothing)
                    unigram_prob = (self.unigram_counts.get(candidate, 0) + 1) / (
                            sum(self.unigram_counts.values()) + len(self.unigram_counts)
                    )
                    score += self.lambda_1 * unigram_prob
                    # Bigram probabilities (with smoothing)
                    if i > 0:
                        bigram = corrected_text[i - 1] + candidate
                        bigram_prob = (self.bigram_counts.get(bigram, 0) + 1) / (
                                self.unigram_counts.get(corrected_text[i - 1], 0) + len(self.unigram_counts)
                        )
                    else:
                        bigram_prob = unigram_prob
                    score += self.lambda_2 * bigram_prob
                    # Trigram probabilities (with smoothing)
                    if i > 1:
                        trigram = corrected_text[i - 2] + corrected_text[i - 1] + candidate
                        trigram_prob = (self.trigram_counts.get(trigram, 0) + 1) / (
                                self.bigram_counts.get(corrected_text[i - 2] + corrected_text[i - 1], 0) + len(
                            self.unigram_counts)
                        )
                    else:
                        trigram_prob = bigram_prob
                    score += self.lambda_3 * trigram_prob
                    # 4-gram probabilities (with smoothing)
                    if i > 2:
                        fourgram = corrected_text[i - 3] + corrected_text[i - 2] + corrected_text[i - 1] + candidate
                        fourgram_prob = (self.fourgram_counts.get(fourgram, 0) + 1) / (
                                self.trigram_counts.get(
                                    corrected_text[i - 3] + corrected_text[i - 2] + corrected_text[i - 1], 0) + len(
                            self.unigram_counts)
                        )
                    else:
                        fourgram_prob = trigram_prob
                    score += self.lambda_4 * fourgram_prob
                    # TODO Bigram, trigram, and 4-gram probabilities

                    if score > best_score:
                        best_score = score
                        best_char = candidate

                # Calculate score for the original character
                original_score = 0

                # Unigram probability
                original_unigram_prob = (self.unigram_counts.get(char, 0) + 1) / (
                        sum(self.unigram_counts.values()) + len(self.unigram_counts)
                )
                original_score += self.lambda_1 * original_unigram_prob

                # Bigram probabilities
                if len(left_context) > 0:
                    original_bigram_left = left_context[-1] + char
                    original_bigram_left_prob = (self.bigram_counts.get(original_bigram_left, 0) + 1) / (
                            self.unigram_counts.get(left_context[-1], 0) + len(self.unigram_counts)
                    )
                    original_score += self.lambda_2 * original_bigram_left_prob

                # Only replace if the new score is significantly better
                threshold = 1.2 + self.error_probs.get(char, 0) * 3  # Dynamic threshold based on error probability
                if best_score > original_score * threshold:
                    corrected_text[i] = best_char
        return ''.join(corrected_text)

    def _correct_with_ml(self, text: str) -> str:
        """
        Correct text using machine learning model.

        Args:
            text: Input text.

        Returns:
            Corrected text.
        """
        # TODO
        features = []
        features = self._get_feature(source=text)
        error_predictions = self.error_detector.predict([list(feature.values()) for feature in features])
        corrected_text = list(text)
        for i, is_error in enumerate(error_predictions):
            if is_error and self.error_probs.get(text[i], 0) >= 0.05:
                correction_encode = self.correction_predictor.predict([list(feature.values()) for feature in features])[
                    0]
                correction = self.label_encoder.inverse_transform([correction_encode])[0]
                corrected_text[i] = chr(correction)
                # print(f"Corrected '{text[i]}' to '{corrected_text[i]}'")
        return ''.join(corrected_text)


    # 新增BERT-LSTM专用方法
    class CorrectionDataset(Dataset):
        def __init__(self, data, tokenizer, char_vocab, max_len=128):
            self.data = data
            self.tokenizer = tokenizer
            self.char_vocab = char_vocab
            self.max_len = max_len

        def __len__(self):
            return len(self.data)

        def __getitem__(self, idx):
            sample = self.data[idx]
            source = sample['source']
            target = sample['target']

            # Tokenize with BERT tokenizer
            encoding = self.tokenizer.encode_plus(
                source,
                add_special_tokens=True,
                max_length=self.max_len,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )

            # Convert target characters to indices
            target_ids = [self.char_vocab.get(c, 0) for c in target][:self.max_len]
            padding = [0] * (self.max_len - len(target_ids))
            target_ids = torch.tensor(target_ids + padding, dtype=torch.long)

            return {
                'input_ids': encoding['input_ids'].flatten(),
                'attention_mask': encoding['attention_mask'].flatten(),
                'labels': target_ids
            }


        class BERTLSTMModel(nn.Module):
            def __init__(self, bert_model, hidden_size, vocab_size, num_layers=2):
                super().__init__()
                self.bert = bert_model
                self.lstm = nn.LSTM(
                    input_size=self.bert.config.hidden_size,
                    hidden_size=hidden_size,
                    num_layers=num_layers,
                    bidirectional=True,
                    batch_first=True
                )
                self.classifier = nn.Linear(hidden_size * 2, vocab_size)

            def forward(self, input_ids, attention_mask):
                with torch.no_grad():
                    bert_output = self.bert(
                        input_ids=input_ids,
                        attention_mask=attention_mask
                    )[0]  # (batch_size, seq_len, hidden_size)

                lstm_out, _ = self.lstm(bert_output)
                logits = self.classifier(lstm_out)
                return logits


        def _train_bert_lstm_model(self, train_data):
            """训练BERT-LSTM混合模型"""
            print("Initializing BERT-LSTM model...")

            # 初始化BERT和Tokenizer
            self.tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
            bert_model = BertModel.from_pretrained('bert-base-chinese')

            # 构建字符词汇表
            all_chars = set()
            for sample in train_data:
                all_chars.update(sample['target'])
            self.char_vocab = {c: i + 1 for i, c in enumerate(all_chars)}  # 0保留给padding
            self.char_vocab['[PAD]'] = 0
            vocab_size = len(self.char_vocab)

            # 初始化模型
            self.lstm_model = self.BERTLSTMModel(
                bert_model=bert_model,
                hidden_size=256,
                vocab_size=vocab_size
            ).to(self.device)

            # 准备数据集
            dataset = self.CorrectionDataset(
                train_data,
                self.tokenizer,
                self.char_vocab
            )
            dataloader = DataLoader(dataset, batch_size=16, shuffle=True)

            # 训练参数
            criterion = nn.CrossEntropyLoss(ignore_index=0)
            optimizer = torch.optim.AdamW(self.lstm_model.parameters(), lr=1e-3)
            num_epochs = 5

            # 训练循环
            self.lstm_model.train()
            for epoch in range(num_epochs):
                total_loss = 0
                for batch in dataloader:
                    optimizer.zero_grad()

                    input_ids = batch['input_ids'].to(self.device)
                    attention_mask = batch['attention_mask'].to(self.device)
                    labels = batch['labels'].to(self.device)

                    outputs = self.lstm_model(input_ids, attention_mask)
                    loss = criterion(
                        outputs.view(-1, outputs.shape[-1]),
                        labels.view(-1)
                    )

                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()

                print(f"Epoch {epoch + 1} Loss: {total_loss / len(dataloader):.4f}")

            print("BERT-LSTM model training completed.")


        def _correct_with_bert_lstm(self, text: str) -> str:
            """使用BERT-LSTM模型进行纠错"""
            self.lstm_model.eval()

            # 预处理输入
            encoding = self.tokenizer.encode_plus(
                text,
                add_special_tokens=True,
                max_length=128,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )

            # 转换为Tensor
            input_ids = encoding['input_ids'].to(self.device)
            attention_mask = encoding['attention_mask'].to(self.device)

            # 预测
            with torch.no_grad():
                outputs = self.lstm_model(input_ids, attention_mask)
                predictions = torch.argmax(outputs, dim=-1)

            # 转换回字符
            pred_ids = predictions[0].cpu().numpy()
            corrected_chars = []
            for idx in pred_ids:
                if idx == 0:  # 跳过padding部分
                    continue
                char = [k for k, v in self.char_vocab.items() if v == idx]
                if char:
                    corrected_chars.append(char[0])

            # 重建文本（去掉特殊token）
            decoded = self.tokenizer.decode(input_ids[0], skip_special_tokens=True)
            original_chars = list(decoded)

            # 对齐预测结果
            final_text = []
            for orig_char, pred_char in zip(original_chars, corrected_chars[:len(original_chars)]):
                # 只替换置信度高的错误
                if orig_char != pred_char:
                    final_text.append(pred_char)
                else:
                    final_text.append(orig_char)

            return ''.join(final_text)
