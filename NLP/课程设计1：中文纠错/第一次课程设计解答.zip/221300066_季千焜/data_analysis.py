#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Data analysis module for Chinese Text Correction task.
This module provides functions for analyzing error patterns in the dataset.
"""

import re
import json
import numpy as np
from typing import Dict, List, Tuple, Any
from collections import Counter, defaultdict
import Levenshtein #get_edits使用

# Try to import optional dependencies for visualization
try:
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    print("Warning: matplotlib not available. Visualization features will be disabled.")


def get_edits(src_text: str, tgt_text: str) -> List[Tuple]:
    """
    Calculate edit operations between source text and target text.
    标准化编辑操作为：M(插入)、S(替换)、R(删除)
    """
    edits = Levenshtein.opcodes(src_text, tgt_text)

    result = []
    for op in edits:
        op_type, src_start, src_end, tgt_start, tgt_end = op
        src_part = src_text[src_start:src_end]
        tgt_part = tgt_text[tgt_start:tgt_end]

        if op_type == 'equal':
            continue
        elif op_type == 'insert':
            # 插入操作：在src_start位置插入tgt_part
            result.append(('M', src_start, src_start, tgt_part))
        elif op_type == 'delete':
            # 删除操作：删除src_start到src_end的字符
            result.append(('R', src_start, src_end))
        elif op_type == 'replace':
            # 替换操作：替换src段的字符为tgt_part
            result.append(('S', src_start, src_end, tgt_part))

    # 合并相邻操作
    merged = []
    for edit in result:
        if merged and merged[-1][0] == edit[0]:
            last = merged[-1]
            # 合并连续替换
            if edit[0] == 'S' and last[2] == edit[1]:
                merged[-1] = ('S', last[1], edit[2], last[3] + edit[3])
            # 合并连续删除
            elif edit[0] == 'R' and last[2] == edit[1]:
                merged[-1] = ('R', last[1], edit[2])
            else:
                merged.append(edit)
        else:
            merged.append(edit)

    return merged


def analyze_data(data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyze the dataset to extract statistics and error patterns.

    Args:
        data: List of dictionaries containing the data.

    Returns:
        Dictionary containing analysis results.
    """
    # TODO 完成数据分析，可以从数据中观察统计信息、错误模式和难度分布等，帮助后续的方法设计。
    analysis = {
        'total_samples': len(data),
        'error_samples': 0,
        'error_rate': 0.0,
        'error_type_dist': Counter(),
        'char_confusion': Counter(),
        'insert_lengths': [],
        'delete_lengths': [],
        'replace_lengths': [],
        'error_pos_bins': np.zeros(10, dtype=int),
        'sent_len_bins': np.zeros(10, dtype=int),
    }

    for d in data:
        src, tgt, label = d['source'], d['target'], d['label']
        if label != 1:
            continue
        analysis['error_samples'] += 1

        edits = get_edits(src, tgt)
        L = len(src) or 1
        for op in edits:
            typ = op[0]
            analysis['error_type_dist'][typ] += 1

            # 记录各类操作长度
            if typ == 'M':
                analysis['insert_lengths'].append(len(op[3]))
            elif typ == 'R':
                analysis['delete_lengths'].append(op[2] - op[1])
            elif typ == 'S':
                analysis['replace_lengths'].append(max(op[2] - op[1], len(op[3])))

            # 替换错误的字符对
            if typ == 'S' and len(op[3]) == 1:
                wrong = src[op[1]:op[2]]
                corr = op[3]
                analysis['char_confusion'][(wrong, corr)] += 1

            # 错误位置分箱（10 等分）
            pos = op[1] / L
            bin_idx = min(int(pos * 10), 9)
            analysis['error_pos_bins'][bin_idx] += 1

        # 句长分箱（10 等分，以最长 100 字为例）
        sl = len(src)
        bin_idx = min(sl * 10 // 100, 9)
        analysis['sent_len_bins'][bin_idx] += 1

    analysis['error_rate'] = analysis['error_samples'] / analysis['total_samples']
    return analysis


def visualize_error_distribution(analysis_results: Dict[str, Any]) -> None:
    """
    Visualize the error distribution from analysis results.

    Args:
        analysis_results: Dictionary containing analysis results.
    """
    if not MATPLOTLIB_AVAILABLE:
        print("Cannot visualize results: matplotlib not available.")
        return

    # TODO 可视化数据分析
        # 1. 错误类型柱状图
        types, counts = zip(*analysis_results['error_type_dist'].items())
        plt.figure(figsize=(8, 4))
        plt.bar(types, counts)
        plt.title('Error Type Distribution')
        plt.xlabel('Operation Type (M=insert, R=delete, S=replace)')
        plt.ylabel('Count')
        plt.show()

        # 2. 替换字符对热力图（取前 20 对）
        top_pairs = analysis_results['char_confusion'].most_common(20)
        chars = list({c for (c, _) in top_pairs} | {c for (_, c) in top_pairs})
        idx = {c: i for i, c in enumerate(chars)}
        mat = np.zeros((len(chars), len(chars)), dtype=int)
        for (w, t), cnt in top_pairs:
            mat[idx[w], idx[t]] = cnt
        plt.figure(figsize=(6, 6))
        plt.imshow(mat, interpolation='nearest')
        plt.xticks(range(len(chars)), chars, rotation=90)
        plt.yticks(range(len(chars)), chars)
        plt.colorbar()
        plt.title('Top-20 Character Confusion')
        plt.show()

        # 3. 错误位置分布条形图
        bins = list(range(1, 11))
        plt.figure(figsize=(8, 3))
        plt.bar(bins, analysis_results['error_pos_bins'])
        plt.xticks(bins, [f'{i * 10}-{(i + 1) * 10}%' for i in range(10)])
        plt.title('Error Position Distribution')
        plt.show()

        # 4. 句长分布条形图
        plt.figure(figsize=(8, 3))
        plt.bar(bins, analysis_results['sent_len_bins'])
        plt.xticks(bins, [f'{i * 10}-{(i + 1) * 10}%' for i in range(10)])
        plt.title('Sentence Length Distribution')
        plt.show()
