#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Rule-based corrector for Chinese Text Correction task.
This module implements rule-based methods for correcting errors in Chinese text.
"""

import re
import json
from typing import Dict, List, Tuple, Any, Set
from collections import Counter, defaultdict #用于pair_counts
from evaluation import get_edits

# Try to import optional dependencies
try:
    import jieba

    JIEBA_AVAILABLE = True
except ImportError:
    JIEBA_AVAILABLE = False
    print("Warning: jieba not available. Some features will be disabled.")


class RuleBasedCorrector:
    """
    A rule-based corrector for Chinese text.
    """

    def __init__(self):
        """
        Initialize the rule-based corrector.
        """
        # Common confusion pairs (similar characters)
        self.confusion_pairs = {}

        # Punctuation rules
        self.punctuation_rules = {}

        # Grammar rules
        self.grammar_rules = {}

        # Common word pairs (for word-level correction)
        self.word_confusion = {}

        # Quantifier-noun pairs (for measure word correction)
        self.quantifier_noun_pairs = {}

        # or else

    def train(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Extract rules from the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # TODO 完成规则方法的实现，可以参考如下的方法，或者自行设计
        self._extract_confusion_pairs(train_data)
        self._extract_punctuation_rules(train_data)
        self._extract_grammar_rules(train_data)
        self._extract_word_confusion(train_data)

    def _extract_confusion_pairs(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Extract character confusion pairs from the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # Extract character-level confusion pairs from error examples
        for sample in train_data:
            if sample['label'] == 1:  # Only for sentences with errors
                source = sample['source']
                target = sample['target']

                # For character substitution errors (when lengths are equal)
                if len(source) == len(target):
                    for i, (s_char, t_char) in enumerate(zip(source, target)):
                        if s_char != t_char:
                            # Get context (surrounding characters)
                            left_context = source[max(0, i - 2) : i]
                            right_context = source[i + 1 : min(len(source), i + 3)]
                            context = left_context + '_' + right_context

                            # Add to confusion pairs with context
                            if s_char not in self.confusion_pairs:
                                self.confusion_pairs[s_char] = defaultdict(int)
                            self.confusion_pairs[s_char][t_char] += 1

        # Filter confusion pairs to keep only the most common ones
        filtered_pairs = {}
        for wrong_char, corrections in self.confusion_pairs.items():
            # Keep only corrections that appear at least twice
            common_corrections = {correct: count for correct, count in corrections.items() if count >= 2}
            if common_corrections:
                filtered_pairs[wrong_char] = common_corrections

        self.confusion_pairs = filtered_pairs

    def _extract_punctuation_rules(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Extract punctuation correction rules from the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # TODO(deepseek)
        """
            从标注中学习全/半角及中/英标点映射。
            """
        full = "，。！？；：“”‘’（）【】…—～《》"
        half = ",.!?;:\"\"''()[]...-~<>"
        for s in full + half:
            self.punctuation_rules[s] = None

        for sample in train_data:
            if sample['label'] != 1: continue
            for sc, tc in zip(sample['source'], sample['target']):
                if sc != tc and sc in full + half and tc in full + half:
                    self.punctuation_rules[sc] = tc

        # 删除无效映射
        self.punctuation_rules = {k: v for k, v in self.punctuation_rules.items() if v}
        return

    def _extract_grammar_rules(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Extract grammar correction rules from the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # TODO
        """
            简单归纳常见语序或搭配错误，如“的地得”混用、“在…不…”等。
            这里是两条最典型模式，更多可自己扩展。
            """
        # 定义模式及其候选替换
        self.grammar_rules = {
            r'的地得': ['的', '地', '得'],
            r'在\s*不\s*': ['不在', '不…在']
        }
        return

    def _extract_word_confusion(self, train_data: List[Dict[str, Any]]) -> None:
        """
        Extract word-level confusion pairs from the training data.

        Args:
            train_data: List of dictionaries containing the training data.
        """
        # TODO
        """
            学习常见易混淆词对，如“环境—环 境”、“进行—进 行”等。
            以读音或形近词为基础聚类。
            """
        pair_counts = Counter()
        for sample in train_data:
            if sample['label'] != 1: continue
            src_tokens = sample['source'].split()
            tgt_tokens = sample['target'].split()
            if len(src_tokens) != len(tgt_tokens): continue
            for s, t in zip(src_tokens, tgt_tokens):
                if s != t:
                    pair_counts[(s, t)] += 1

        # 仅保留出现频次 >=2 的词对
        self.word_confusion = {p: c for p, c in pair_counts.items() if c >= 2}
        return

    def correct(self, text: str) -> str:
        """
        Apply rule-based correction to the input text.

        Args:
            text: Input text to correct.

        Returns:
            Corrected text.
        """
        # Apply different correction rules in sequence
        # TODO 对应规则方法的实现，完成修正部分（可以参考如下的方法，或者自行设计）
        corrected_text = list(text)

        for i, char in enumerate(text):
            if char in self.confusion_pairs and self.confusion_pairs[char]:
                # Get the most common correction (based on stored counts)
                # Need to find max value in the inner dict
                best_correction = None
                max_count = 0
                for correct_char, count in self.confusion_pairs[char].items():
                    if count > max_count:
                        max_count = count
                        best_correction = correct_char

                # If a best correction is found and it's different
                if best_correction and best_correction != char:
                    # Apply specific rules for 的/地/得 and 在/再 from rule.py example
                    # Note: These rules are quite basic and might need jieba if using POS
                    if char == '的' and best_correction in ['地', '得']:
                        if i < len(text) - 1 and text[i + 1] in '走跑跳跃飞奔':  # Simple verb check
                            corrected_text[i] = '地'
                        elif i > 0 and text[i - 1] in '说写跑跳走看听闻感觉':  # Simple verb check
                            # Check if next word implies adjective/adverb (hard without POS)
                            # Let's stick to the verb-before rule for '得' for simplicity here
                            corrected_text[i] = '得'
                        # Default to '的' if unsure or other rules apply
                        # But since we are correcting '的', only change if rules match
                    elif char == '地' and best_correction in ['的', '得']:
                        # Similar reverse logic - if context doesn't strongly suggest 地, revert
                        if i > 0 and text[i - 1] not in ['慢慢', '悄悄']:  # Example adverbs
                            # Needs better logic, maybe default to 的?
                            pass  # Keep as 地 for now unless more rules
                    elif char == '得' and best_correction in ['的', '地']:
                        # Similar reverse logic
                        pass  # Keep as 得 for now
                    elif char == '在' and best_correction == '再':
                        if i < len(text) - 1 and text[i + 1] in '次遍回见':
                            corrected_text[i] = '再'
                    elif char == '再' and best_correction == '在':
                        if i > 0 and text[i - 1] in '正将':  # Less reliable check
                            corrected_text[i] = '在'
                        # Add check for place words? Needs jieba or list
                        elif i < len(text) - 1 and text[i + 1] in '哪里这那家门口':  # Simple place check
                            corrected_text[i] = '在'

                    # Generic correction based on frequency threshold (from rule.py)
                    # Only apply if specific rules above didn't trigger a change
                    elif corrected_text[i] == char and max_count > 5:  # Arbitrary threshold from rule.py
                        corrected_text[i] = best_correction

        return ''.join(corrected_text)

    def _correct_punctuation(self, text: str) -> str:
        """
        Correct punctuation errors in the text.

        Args:
            text: Input text.

        Returns:
            Text with corrected punctuation.
        """
        # TODO
        corrected = []
        for char in text:
            corrected.append(self.punctuation_rules.get(char, char))
        return ''.join(corrected)
        #return ''.join(self.punctuation_rules.get(ch, ch) for ch in text)
        #return text


    def _correct_confusion_chars(self, text: str) -> str:
        """
        Correct character confusion errors in the text.

        Args:
            text: Input text.

        Returns:
            Text with corrected characters.
        """
        corrected_text = list(text)  # Convert to list for character-by-character editing

        # Check each character for potential confusion
        for i, char in enumerate(text):
            if char in self.confusion_pairs and self.confusion_pairs[char]:
                # Get the most common correction for this character
                correct_char = max(self.confusion_pairs[char].items(), key=lambda x: x[1])[0]

                # Apply some heuristics to decide whether to correct
                # For example, check if the correction makes sense in this context
                # This is a simplified approach; in a real system, more context would be considered

                # For the common confusion of 的/地/得, apply specific rules
                if char == '的' and correct_char in ['地', '得']:
                    # '地' typically follows an adjective and precedes a verb
                    if i > 0 and i < len(text) - 1 and text[i + 1] not in ',.?!，。？！、；：':
                        # Simple check: if followed by a verb-like character, might be '地'
                        if text[i + 1] in '走跑跳跃飞奔跑跳跃飞奔跑跳跃飞奔':
                            corrected_text[i] = '地'

                    # '得' typically follows a verb and precedes an adjective or adverb
                    if i > 0 and i < len(text) - 1 and text[i - 1] not in ',.?!，。？！、；：':
                        # Simple check: if preceded by a verb-like character, might be '得'
                        if text[i - 1] in '说写跑跳走看听闻感觉':
                            corrected_text[i] = '得'

                # For other confusions, apply a simpler rule
                elif char in ['在', '再'] and correct_char in ['再', '在']:
                    # '在' typically indicates location, '再' typically indicates repetition or future action
                    if i < len(text) - 1 and text[i + 1] in '次遍回':
                        corrected_text[i] = '再'
                    elif i > 0 and text[i - 1] in '正将':
                        corrected_text[i] = '在'

                # For other cases, only correct if we're very confident
                # This is a placeholder for more sophisticated rules
                elif self.confusion_pairs[char][correct_char] > 5:  # Arbitrary threshold
                    corrected_text[i] = correct_char

                # TODO more rules


        return ''.join(corrected_text)

    def _correct_grammar(self, text: str) -> str:
        """
        修正常见语法错误（的地得混淆、重复助词等）

        修改点：
        1. 改进正则表达式匹配模式
        2. 增加匹配回调函数的参数处理
        3. 添加默认返回值逻辑
        """
        patterns = [
            # 匹配中文词语后接错误助词（支持4-6字词语）
            (r'([\u4e00-\u9fa5]{2,6})[的地得]', self._correct_de_pattern),
            # 匹配连续重复的介词（如"在在"）
            (r'(在|从|对|把){2,}', self._correct_repetition)
        ]

        for pattern, func in patterns:
            text = re.sub(pattern, lambda m: func(m), text)  # 通过lambda保证参数传递

        return text

    def _correct_de_pattern(self, match: re.Match) -> str:
        """处理的地得混淆"""
        # 获取匹配组
        word = match.group(1)
        wrong_char = match.group(0)[-1]  # 提取错误的助词

        # 示例判断逻辑（实际应接入词性标注模型）
        if any(c in word for c in ['开心', '迅速', '认真']):  # 形容词+地
            return f'{word}地'
        elif any(c in word for c in ['跑', '看', '吃']):  # 动词+得
            return f'{word}得'
        else:  # 默认返回的
            return f'{word}的'

    def _correct_repetition(self, match: re.Match) -> str:
        """处理重复助词"""
        return match.group(1)  # 保留第一个匹配字符

    def _correct_word_confusion(self, text: str) -> str:
        """
        Correct word-level confusion errors in the text.

        Args:
            text: Input text.

        Returns:
            Text with corrected words.
        """
        # TODO
        for (w, t), cnt in self.word_confusion.items():
            if w in text:
                text = text.replace(w, t)
        return text
