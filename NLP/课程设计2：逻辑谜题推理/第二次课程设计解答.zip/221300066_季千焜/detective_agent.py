import os
import json
import asyncio
import aiohttp
import logging
import time
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("detective_agents.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 确保结果目录存在
RESULTS_DIR = "results"
os.makedirs(RESULTS_DIR, exist_ok=True)

class ZhipuAI:
    """智谱AI接口封装"""
    
    def __init__(self, api_token: str, api_url: str = "https://open.bigmodel.cn/api/paas/v4/chat/completions"):
        self.api_token = api_token
        self.api_url = api_url
        self.headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}
        self._session = None
        
    async def get_session(self) -> aiohttp.ClientSession:
        """获取或创建HTTP会话"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    async def close_session(self):
        """关闭HTTP会话"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    async def chat_completion(self, 
                             messages: List[Dict], 
                             model: str = "glm-z1-flash",
                             temperature: float = 0.7,
                             max_tokens: int = 12000,
                             stream: bool = False) -> Dict:
        """调用GLM模型进行聊天补全"""
        try:
            session = await self.get_session()
            
            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "stream": stream
            }
            
            async with session.post(self.api_url, headers=self.headers, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"API调用失败: {response.status} - {error_text}")
                    return {"success": False, "error": f"HTTP错误 {response.status}: {error_text}"}
                
                data = await response.json()
                return {"success": True, "data": data}
                
        except Exception as e:
            logger.error(f"调用API出错: {str(e)}")
            return {"success": False, "error": f"调用API异常: {str(e)}"}


class Character:
    """角色基类"""
    
    def __init__(self, name: str, role: str, background: str, ai_client: ZhipuAI, model: str = "glm-z1-flash"):
        self.name = name
        self.role = role
        self.background = background
        self.ai_client = ai_client
        self.model = model
        self.messages = []
        self.system_prompt = ""
        self.initialize_system_prompt()
    
    def initialize_system_prompt(self):
        """初始化系统提示"""
        self.system_prompt = f"你扮演{self.name}，一个{self.role}。{self.background}"
        self.messages = [{"role": "system", "content": self.system_prompt}]
    
    async def respond(self, message: str, temperature: float = 0.7,max_tokens: int=12000) -> str:
        """响应一条消息"""
        self.messages.append({"role": "user", "content": message})
        
        response = await self.ai_client.chat_completion(
            messages=self.messages,
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens 
        )
        
        if not response.get("success", False):
            logger.error(f"{self.name} 响应出错: {response.get('error', '未知错误')}")
            return f"[{self.name} 未能回应，技术故障]"
        
        assistant_message = response["data"]["choices"][0]["message"]
        content = assistant_message.get("content", "")
        
        # 将助手的回复添加到消息历史
        self.messages.append({"role": "assistant", "content": content})
        
        # 返回格式化的响应
        return f"{self.name}: {content}"


class Detective(Character):
    """侦探角色"""
    
    def __init__(self, name: str, ai_client: ZhipuAI, model: str = "glm-z1-flash"):
        super().__init__(
            name=name,
            role="侦探",
            background="你是一位经验丰富的侦探，精通推理、观察和心理分析。你负责调查都铎庄园发生的谋杀案。"
            "你的目标是找出谁杀害了约翰·Q·博迪（John Q. Bodie）。",
            ai_client=ai_client,
            model=model
        )
        self.clues = []
        self.suspects = {}
        self.interrogation_log = {}
        
    def initialize_system_prompt(self):
        """初始化侦探的系统提示"""
        self.system_prompt = f"""你扮演{self.name}，一位经验丰富的侦探。你正在调查都铎庄园发生的谋杀案。

背景信息：
十二月寒夜，都铎庄园举行晚宴，宴毕次日清晨发现主宾约翰·Q·博迪（John Q. Bodie）死于马车房。现场发现可能的凶器线索包括马蹄铁、扳手、铅管、绳索。案发时段锁定在22:00至01:00之间，凶手和受害者须独处一段时间且凶器留于现场。

你的任务是通过询问嫌疑人、分析线索，找出谁是真正的凶手。请注意以下几点：
1. 你应该使用逻辑推理和证据分析，而不是直接猜测
2. 所有嫌疑人都可能说谎或隐瞒信息
3. 注意时间线和物理证据的一致性
4. 记录关键信息，特别是任何矛盾或可疑之处
5. 你的目标是在最后给出合理的结论，包括凶手、凶器和作案动机

请以侦探角色回应，用第一人称说话，保持专业态度，但要有个性和风格。"""
        self.messages = [{"role": "system", "content": self.system_prompt}]
    
    async def collect_evidence(self) -> str:
        """收集现场证据"""
        message = """现在你正在马车房中调查约翰·Q·博迪的尸体和案发现场。
请描述你观察到的证据，并说明初步的调查方向。
注意描述你发现的物理证据（如凶器、血迹、脚印等）及其位置和状态。"""
        
        response = await self.respond(message, temperature=0.6, max_tokens=12000)
        return response
    
    async def prepare_questions(self) -> str:
        """准备问题清单"""
        message = """基于你已收集的证据，请列出你计划向每位嫌疑人提问的关键问题。
这些问题应该有助于确认他们的不在场证明、动机和与案件的关联。"""
        
        response = await self.respond(message, temperature=0.5, max_tokens=12000)
        return response
    
    async def interrogate(self, suspect_name: str, response: str) -> str:
        """审问嫌疑人并记录反应"""
        # 添加嫌疑人的回答到侦探的消息历史
        self.messages.append({"role": "user", "content": f"嫌疑人{suspect_name}回答: {response}"})
        
        # 生成侦探的下一个问题或反应
        question_prompt = f"""根据{suspect_name}的回答，你想要进一步深入了解什么细节？
或者你注意到了什么可疑之处？请提出你的下一个问题或表达你对回答的看法。"""
        
        self.messages.append({"role": "user", "content": question_prompt})
        
        response = await self.ai_client.chat_completion(
            messages=self.messages,
            model=self.model,
            temperature=0.7
        )
        
        if not response.get("success", False):
            logger.error(f"侦探审问出错: {response.get('error', '未知错误')}")
            return f"[侦探没有进一步提问，技术故障]"
        
        assistant_message = response["data"]["choices"][0]["message"]
        content = assistant_message.get("content", "")
        
        # 将助手的回复添加到消息历史
        self.messages.append({"role": "assistant", "content": content})
        
        # 保存审问记录
        if suspect_name not in self.interrogation_log:
            self.interrogation_log[suspect_name] = []
        self.interrogation_log[suspect_name].append(content)
        
        # 返回格式化的响应
        return f"{self.name}: {content}"
    
    async def analyze_clues(self) -> str:
        """分析收集到的线索"""
        message = """根据你目前收集到的所有证据和嫌疑人的证词，请进行全面分析。
指出任何矛盾之处、可疑的行为、时间线问题，以及潜在的作案动机。
暂时不要给出最终结论，只进行分析。"""
        
        response = await self.respond(message, temperature=0.6,max_tokens=12000)
        return response
    
    async def second_round_questioning(self, suspect_name: str, previous_answers: str) -> str:
        """基于分析进行二次询问"""
        message = f"""基于你的分析，你决定对{suspect_name}进行二次询问。
你注意到以下可疑点或矛盾：

{previous_answers}

请提出更有针对性的问题，试图突破嫌疑人的防线或揭露矛盾。"""
        
        response = await self.respond(message, temperature=0.7, max_tokens=12000)
        return response
    
    async def solve_case(self) -> str:
        """解决案件，给出最终结论"""
        message = """现在，基于所有收集到的证据和嫌疑人的证词，给出你的最终结论。
明确指出：
1. 谁是凶手
2. 使用了什么凶器
3. 作案动机是什么
4. 作案手法和时间
5. 关键证据是什么

请详细解释你的推理过程，说明为什么其他嫌疑人可以排除，以及为何你认定的凶手是确定无疑的。"""
        
        response = await self.respond(message, temperature=0.5, max_tokens=12000)
        return response


class Suspect(Character):
    """嫌疑人角色"""
    
    def __init__(self, 
                name: str, 
                public_info: str,
                hidden_info: str,
                relationships: str,
                has_motive: bool,
                timeline: str,
                clues: str,
                script: str,
                ai_client: ZhipuAI, 
                model: str = "glm-z1-flash"):
        self.public_info = public_info
        self.hidden_info = hidden_info
        self.relationships = relationships
        self.has_motive = has_motive
        self.timeline = timeline
        self.clues = clues
        self.script = script
        
        super().__init__(
            name=name,
            role="嫌疑人",
            background=f"{public_info} {hidden_info} {relationships} {timeline} {clues}",
            ai_client=ai_client,
            model=model
        )
    
    def initialize_system_prompt(self):
        """初始化嫌疑人的系统提示"""
        self.system_prompt = f"""你扮演{self.name}，约翰·Q·博迪谋杀案的嫌疑人。请严格按照以下角色设定回答侦探的问题：

1. 公开身份：{self.public_info}
2. 隐藏信息：{self.hidden_info}
3. 与其他人的关系：{self.relationships}
4. 是否有杀害博迪的动机：{'是' if self.has_motive else '否'}
5. 案发当晚的时间线：{self.timeline}
6. 你可能知道的线索：{self.clues}

角色剧本：
{self.script}

回答原则：
1. 你会尽力保护自己，隐藏可能对自己不利的信息
2. 如果你是凶手，你会试图误导侦探，但不要明显撒谎
3. 如果被问及你直接知道的事实，要如实回答
4. 如果被问及其他人的行为，可以据实回答你所见到的部分
5. 保持角色的个性特点，包括说话方式和态度
6. 对于侦探的尖锐提问，表现出相应的紧张、愤怒或困惑
7. 你不知道谁是真正的凶手，除非你自己就是凶手

重要提示：请用第一人称回答，表现出你角色的情感和性格。回答要自然、符合人物设定，不要过于生硬或明显地隐瞒信息。"""
        
        self.messages = [{"role": "system", "content": self.system_prompt}]


class Dispatcher:
    """调度员类，用于协调多个智能体"""
    
    def __init__(self, api_token: str, api_url: str, model: str = "glm-z1-flash"):
        self.ai_client = ZhipuAI(api_token=api_token, api_url=api_url)
        self.model = model
        self.detective = None
        self.suspects = {}
        self.conversation_history = []
        self.case_file = {
            "case_name": "都铎庄园谋杀案",
            "victim": "约翰·Q·博迪",
            "time_of_death": "22:00-01:00之间",
            "location": "马车房",
            "possible_weapons": ["马蹄铁", "扳手", "铅管", "绳索"],
            "investigation_log": [],
            "interrogations": {},
            "conclusions": "",
            "solved": False
        }
    
    def setup_characters(self):
        """设置所有角色"""
        # 创建侦探
        self.detective = Detective(
            name="霍姆斯侦探",
            ai_client=self.ai_client,
            model=self.model
        )
        
        # 创建格雷中士
        self.suspects["格雷中士"] = Suspect(
            name="格雷中士",
            public_info="前军人、都铎庄园马厩管家，身着军装，脾性严肃、行事沉稳。",
            hidden_info="内心藏着对博迪先生的刻骨仇恨，多年前未婚妻因他遭祸而身亡，誓要复仇（实际上他就是凶手）。",
            relationships="曾与芥末上校是战友，上校了解他的苦衷与往事；与桃小姐及其他人关系平常无特别交情。",
            has_motive=True,
            timeline="""
            22:00-22:30：晚宴结束后留在马车房为马匹换马蹄铁、整理饲料。
            23:00-23:30：继续在马车房工作，准备翌日马车需要的马具。
            23:30-00:00：注意到博迪先生进入马车房后，两人独处，使用马蹄铁下手杀害博迪。
            00:00-00:30：事后返回马车房门口等待，配合众人表面震惊并帮助"抢救"。
            """,
            clues="凶器马蹄铁（带血迹）、马车房地面泥土印记、自己手上模糊的血迹、博迪旧照片或信件等。",
            script="""格雷中士军容挺拔，身披深色军服，从走廊尽头缓步而来，他面色严肃，肩章在灯光下闪着黯淡的光。作为都铎庄园的马厩管家和前军人，他表面从容冷静，但只有自己知道，心底暗藏着对博迪先生深沉的仇恨。数年前他们曾在战场上并肩作战，共同面对生死，但战后博迪并未信守承诺反而逐利脱身，随后一起意外夺走了格雷未婚妻的生命。那份怨恨在他心中始终难以平息。他对外维护军人般的严谨和礼貌：每日巡查马厩，为马匹换上干净马蹄铁、准备干草和苹果，可从不在人前谈论往事或情感。

晚宴结束后人群散去，格雷如常独自前往马车房清理马具。他小心翼翼地替马匹换好马掌，为锈钉涂油，手指轻抚着刚磨好的马蹄铁，每一个细节都牵动他的神经。午夜钟声临近时，他察觉院中月色格外明亮。正当他整理完马匹，回头时注意到宴会主宾博迪先生独自穿过庭院向马车房走来。格雷心头猛地一沉：博迪来到马车房，说明此刻他与主人才会独处。这么多年的怨恨与复仇决心瞬间涌上心头，他握紧了手中的马蹄铁。

在马车房昏暗的灯光下，他猛然挥出马蹄铁，狠狠地击向出现在面前的人，格雷中士对着博迪目光冰冷："博迪先生，你欠我的，什么时候还？"。剧痛一瞬间传遍全身，空气中弥漫起金属的血腥味。话音未落，此时门口有人奔近，但一切已结束。格雷深吸一口气，将沾满血迹的马蹄铁随手扔向阴影角落，然后赶忙用水擦净双手上和制服上的污迹，整了整衣衬，就如若刚才那一切只是个意外。

不久，其他人惊恐地冲进马车房。布伦特先生惊呼："这怎么可能？！"格雷中士面色平静，无声地压抑着内心。被问及时，他表面冷静地说："我刚才在给马儿换马掌……一转身就看见博迪先生倒在这里了。马车房平日紧闭，可能他自己进来做了什么准备。"他语气淡然，只是轻轻低喃了一句"真是奇怪……"。他没有大声哭喊，只与众人一同沉痛地痛哭，以表面上的悲痛来掩饰自己冰冷无情的真实想法。""",
            ai_client=self.ai_client,
            model=self.model
        )
        
        # 创建桃小姐
        self.suspects["桃小姐"] = Suspect(
            name="桃小姐",
            public_info="年轻女子，体态优雅，身着淡粉色礼服，与博迪家族关系密切，曾被安排与博迪订婚。",
            hidden_info="曾深爱博迪先生却被其抛弃，心中怀有怨恨；与芥末上校有暗地恋情（两人曾私下共舞、悄悄交换过情话）。",
            relationships="与芥末上校存在隐秘的情感牵绊；与格雷中士、罗斯夫人无特别隐秘关系。",
            has_motive=True,
            timeline="""
            22:00-22:30：晚宴中与宾客们寒暄，保持礼貌体面但内心起伏。
            22:30-23:00：借故离席到画室，用绘画抒发情绪。
            23:00-23:30：月下独自沿喷泉散步，发现喷泉边的一根绳索（未告诉他人）。
            23:30-00:00：返回大厅与其他宾客聊天，面对博迪死讯表现震惊悲痛。
            """,
            clues="庭院喷泉旁的绳索（她曾发现）、未拆封的私人信件、自己房间里的博迪旧照片等。",
            script="""桃小姐身姿曼妙，身着剪裁得体的淡粉色礼服，优雅端庄却带着一丝忧郁。她自幼与博迪家族关系亲近，曾被视为家族掌上明珠，甚至被安排与博迪先生订婚。但未婚夫突如其来的失信和抛弃令她心如刀绞，多年遗憾始终盘旋在她心头。晚宴上，她对博迪彬彬有礼，语调淡然，却又饱含无力的哀怨：那一吻的承诺在回忆里酸涩可闻。对于其他来宾，桃小姐则保持体贴好客的礼仪，用轻声谈笑掩饰心中的落寞。实则心底悄然盘算着复仇的阴影。她清楚，自己对博迪既怨恨又留有怜悯，一言一行间始终保持距离。

晚宴过半，她假装前往洗手间，趁机离开喧嚣的人群，绕入庄园的画室。月光从窗外斜射进来，她在画架前凝眸：心中混乱的情绪通过画笔在画布上流淌。墙上挂着她和博迪年轻时的合影，她深吸一口气，试图把对过去的迷恋与怨恨倾注画中。大约到23:00时，她从画室走出，独自沿着庭院的鹅卵石路慢步，来到花园中央的喷泉旁。月光下寒花凋零，清冷的泉水静静涌动。就在此刻，她的手指碰到了一根粗糙的绳索，它湿漉漉地环绕在喷泉边的石壁上，似乎有人刚用它固定过什么。桃小姐皱了皱眉，这根绳索与庄园的装饰格格不入，却不敢大声质问。她蹲下身来端详了片刻，最终摇头放弃，只轻轻将绳索放置原位，没人发现她的这一举动。她只是默默将这发现记在心里。 

返回大厅途中，桃小姐见到罗斯夫人在走廊尽头沉思，她礼貌地上前问候："罗斯夫人，又出来散心了吗？"两人客套寒暄，桃小姐发现对方眼中藏着复杂情绪：罗斯夫人曾遭遇家变，看向她时既有同情也有警惕。桃小姐淡淡一笑："夜风凉意十足，请您也多加披肩。"随后快步离开返回宾客群中。归座时，她发现芥末上校站在角落微笑注视，桃小姐也礼貌地回应并轻声道了晚安。表面上，她随着众人一起沉浸在痛苦和惊讶中，眼角却带着隐约的冷光：今晚的许多事都将是一场谜团，而她自己既是参与者，也有着不为人知的秘密需要守护。""",
            ai_client=self.ai_client,
            model=self.model
        )
        
        # 创建罗斯夫人
        self.suspects["罗斯夫人"] = Suspect(
            name="罗斯夫人",
            public_info="中年贵妇，名门之后，曾与博迪先生合作过生意（后反目），气质优雅睿智。",
            hidden_info="多年前家族生意失败破产，她怀疑博迪暗中插手，对他怀有深刻恨意。",
            relationships="曾与博迪合作经营家业（后闹翻）；对桃小姐表面友好内心警惕；与芥末上校无特别私情。",
            has_motive=True,
            timeline="""
            22:00-22:30：晚宴后独自前往奖杯室沉思，玩弄展柜上的奖杯。
            22:30-23:00：在奖杯室发现一根铅管，将其藏匿起来未告知他人。
            23:00-23:30：信步穿过花园，途中听到骚动声赶往马车房。
            23:30-00:00：面对案发现场，她保持冷静观察众人反应。
            """,
            clues="奖杯室发现的铅管（被她藏匿）、夜晚庭院的动静、博迪过去生意文件等。",
            script="""罗斯夫人身披素雅长披风，举止端庄优雅、眼神却锐利洞察。她是当地名门之后，才智过人，善于揣摩人心。曾经与博迪先生一同打理家族事业，生意失败却归于阴差阳错，她怀疑这背后有博迪一手操作；至此之后，她便将这位昔日伙伴视为仇人，即使面前仍称他"博迪先生"，也难掩恨意。晚宴上，她礼数周到，谈吐不俗，与博迪寒暄时声音温柔却心事沉重。面对年轻貌美的桃小姐，她既赞赏又保持警惕；与格雷中士相处，她默许他维持秩序，但内心思忖这些人是否也有所隐瞒。她深知，每个人都不简单。

晚宴结束后，罗斯夫人独自一人来到庄园的奖杯室。她静静吟诵着自己偏爱的老歌，手指轻触一座银质胜利奖杯，银光在灯下映出她沉静的侧颜。环顾周围，她的心神并不完全安宁：眼光游移中，她发现一根长长的铅管斜靠在奖杯柜旁，锈迹斑斑，与庄园任何布置都不相符。罗斯夫人伸手将铅管拖进阴影，将它轻轻掩在柜后，心中涌起隐约警觉：这根铅管莫非就是今晚谋杀案中凶器的踪迹？然而她没有说破，只是再次确认门窗的锁紧，然后离开了奖杯室，步履稳健。 不久，远处忽然传来慌乱的呼喊，罗斯夫人匆匆走向声源所在的马车房。门口只见众人围成一圈，怀中倒着血泊中的博迪先生。她镇定地站在一旁打量着：格雷中士面色依旧平静，芥末上校则神色震惊，桃小姐泪眼婆娑，布伦特先生忙乱中喊道要报警。她目光在众人间扫过，不动声色，只在心中暗暗推演：门锁向来紧闭，这么多人都在场，凶手到底是谁？此刻所有人都集中注意于博迪先生身边的马蹄铁，却没有人提到她藏匿的那根铅管。她轻轻叹息，清楚真正的凶手可能还混在人群中、暗中凝望着这一切。表面上她痛惜不已，语气低沉地与众人一样哀叹，"好个悲剧……"，心底却已暗自下定决心要揭开迷雾。""",
            ai_client=self.ai_client,
            model=self.model
        )
        
        # 创建芥末上校
        self.suspects["芥末上校"] = Suspect(
            name="芥末上校",
            public_info="年迈退役军官，身材挺拔，阅历丰富，与博迪先生是战时旧识。",
            hidden_info="对桃小姐温柔关怀但克制自重，内心对过往战友怀念，对局势有敏锐判断。",
            relationships="与桃小姐曾暗自往来、有感情默契；与格雷中士是战友；与布伦特先生交情一般。",
            has_motive=True,
            timeline="""
            22:00-22:30：晚宴时与博迪先生及众宾客交谈，谈论往事。
            22:30-23:00：前往台球室独自练球，思考案情。
            23:00-23:30：带水烟壶走到庭院喷泉处吸烟，发现并用上喷泉旁的绳索（并未提及）。
            23:30-00:00：急赴马车房发现博迪尸体，表现震惊并试图安抚众人。
            """,
            clues="庭院喷泉上的绳索（水烟壶和打火机）、对格雷举动的敏锐观察、战争年代的记忆碎片等。",
            script="""芥末上校退役多年，但军中风范依旧：挺拔的身姿和温文的面容透出历练和沉稳。他与格雷中士曾是战友，也与博迪先生年轻时结识；这几年虽偶有冲突，但上校依旧将博迪视作旧友。宴会上，他话语温和地与博迪闲聊往事，谈论军功勋章和征战历程，话里常带几分试探。面对桃小姐，上校总是满脸关切：曾几次在月光下携手起舞，两人悄悄交谈，他对她早生爱慕却没表现。众人并不知，上校心中对往昔战友的怀念掩饰在举止儒雅下。晚宴进行中，他借故去到画室附近的台球厅。厅中只有微弱的灯光，他独自对着球台练习瞄准，白色台球击打在绿色台面上声响清脆。思绪游走中，他低头思索：每个人都藏着秘密，有的隐约可见，有的隐藏更深。

大约在23:00左右，上校提着随身携带的皮袋走出大厅到庭院散步。他来到中央喷泉边，把冰凉的水烟壶放到台阶上，掏出金色打火机准备点燃。正当他凝视着火苗时，一眼瞥见喷泉柱上的一根麻绳闲置着。上校眉头轻皱：这绳子粗旧，显然有人用它固定过喷泉灯，却突然被挂起后随手搁置。他拾起绳索反复端详了一下，然后想起就挂回了喷泉底座，未当众提及。他抿了一口酒精味的水烟，整理衣襟后缓步返回大厅。 忽而传来惊呼声，上校和众人同时冲到马车房门口。他看到博迪先生横在血泊之中，胸口按捺不住涌起悲痛。他扶着门框蹲下，闷声自语："天哪，太难以置信了……"片刻后他压住情绪，对纷乱的人群低声说："大家别慌，我们先理清事实。"他注意到格雷中士面容沉稳，芥末上校与他四目相对时谁也没说破实情。临走前，上校像是在默念军中誓言，用金质打火机在手中把玩，仿佛以此给自己镇定。他暗自观察着每个人的眼神，思索着每句对话，希望从这无声的细节中找到一丝真凶的线索。""",
            ai_client=self.ai_client,
            model=self.model
        )
        
        # 创建布伦特先生
        self.suspects["布伦特先生"] = Suspect(
            name="布伦特先生",
            public_info="庄园管家，忠诚可靠，熟知府中一切事务，举止彬彬有礼。",
            hidden_info="多年来对博迪先生操劳尽心，对主人的命运感同身受；在发现衣帽间的扳手后没向他人透露真相。",
            relationships="与博迪先生关系如家人般亲密；与其他人在礼节上交往，没有秘密私情。",
            has_motive=False,
            timeline="""
            22:00-22:30：晚宴结束后整理府内事务，前往衣帽间准备礼帽。
            22:30-23:00：在衣帽间发现一把生锈的扳手（并将其藏匿）。
            23:00-23:30：奔赴马车房，发现博迪先生遇害，高声呼喊报警。
            23:30-00:00：与其他人交谈、安抚众人，自己表现镇定配合调查。
            """,
            clues="衣帽间内的生锈扳手（他身上藏有）、全屋门锁及钥匙信息、博迪最后行踪记录等。",
            script="""布伦特先生年约四十，身着整洁的礼服，谈吐稳重有礼。他担任庄园管家多年，对博迪先生极度忠诚，待主人如家人般亲切。年轻时他曾与博迪一起学习园艺，庄园的一花一木都留有他的身影。晚宴上他殷勤侍奉宾客，面带谦和的笑容，只在细微之处闪露对主人处境的忧虑：庄园近期的财务亏空让他心事重重。对待格雷中士，他谦恭有礼，经常让对方协助搬运马具；对桃小姐，他态度温和带着几分关怀；与罗斯夫人和芥末上校相处更是周全有礼，表现无可挑剔。他留意到每个人眼中的隐忧，但此刻难以断定那预兆着什么。

晚宴结束，他独自来到衣帽间准备翌日清晨给博迪先生送去礼帽。开柜时突然触到柜底，一把锈迹斑驳的扳手啪嗒掉在地板上。布伦特蹲下拾起扳手查看：上面竟有干硬的泥块痕迹，显然刚被别人用过，却不知道是谁丢在这里。他的胸口猛然紧缩：这把扳手竟然是园艺常用的工具，但为何会出现在衣帽间？为了不引起怀疑，他迅速将扳手揣入身后，抚了抚额头让自己显得若无其事，然后关上柜门，内心波澜涌动却一言不发。 忽然远处传来惊呼声，布伦特连忙赶到马车房。他看到博迪先生横陈血泊，惊愕中强压悲痛，镇定地高喊："有人快报警！"呼喊声中，他低头发现自己衣角微微凸起的扳手，顿时冷汗直冒：这把锈扳手是园丁的工具，如今却沾染了现场气息。他忽然明白凶手最可能就是不小心丢下它的人，但他屏住了这个念头。只见众人四散忙乱，他保持冷静守口如瓶，仿佛什么都没察觉。 格雷中士走来问他："布伦特先生，您还好吗？"布伦特稳了稳情绪，只淡淡回应："没事，我能帮上忙就好。"随后，他向芥末上校和其他人询问："博迪先生最后一次是谁见过？马车房什么时候有人进出过？"他语气平和，尽力配合推理，却没有露出任何异样。即便如此，他心中依旧打起算盘：要查清真相，一定要搜集更多线索。 

布伦特先生举止谦逊，一边陪同众人退出马车房，一边心里默念着要冷静。他紧握那把锈扳手，目光扫过已锁紧的马车房大门和零散的脚印，暗暗揣测每个人的时间线与不在场证明。他默默告诉自己：只有事实才会说话，一切线索都要仔细串联，他愿意为揭露真相尽全力。""",
            ai_client=self.ai_client,
            model=self.model
        )

    async def run_investigation(self):
        """运行整个侦探调查流程"""
        # 确保所有角色已设置
        if not self.detective or not self.suspects:
            self.setup_characters()
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        case_log_file = f"{RESULTS_DIR}/investigation_log_{timestamp}.txt"
        
        with open(case_log_file, 'w', encoding='utf-8') as log_file:
            # 步骤1：侦探收集现场证据
            log_file.write("=== 第一阶段：现场勘查 ===\n\n")
            evidence = await self.detective.collect_evidence()
            log_file.write(f"{evidence}\n\n")
            self.conversation_history.append(evidence)
            self.case_file["investigation_log"].append({
                "phase": "现场勘查",
                "content": evidence
            })
            
            # 步骤2：侦探准备询问的问题
            log_file.write("=== 第二阶段：准备询问 ===\n\n")
            questions = await self.detective.prepare_questions()
            log_file.write(f"{questions}\n\n")
            self.conversation_history.append(questions)
            self.case_file["investigation_log"].append({
                "phase": "准备询问",
                "content": questions
            })
            
            # 步骤3：侦探询问每个嫌疑人
            log_file.write("=== 第三阶段：嫌疑人询问 ===\n\n")
            for name, suspect in self.suspects.items():
                log_file.write(f"--- 询问{name} ---\n\n")
                
                self.case_file["interrogations"][name] = []
                
                # 侦探的第一个问题
                question = f"你好，{name}。我是受委托调查博迪先生死亡一案的霍姆斯侦探。请问你能告诉我，昨晚晚宴结束后，你都在哪里，做了什么？请尽量详细描述，包括时间和你可能见到的人。"
                log_file.write(f"霍姆斯侦探: {question}\n\n")
                self.case_file["interrogations"][name].append({
                    "speaker": "侦探",
                    "content": question
                })
                
                # 嫌疑人的回答
                suspect_response = await suspect.respond(question)
                log_file.write(f"{suspect_response}\n\n")
                self.conversation_history.append(suspect_response)
                self.case_file["interrogations"][name].append({
                    "speaker": name,
                    "content": suspect_response
                })
                
                # 侦探的跟进问题
                follow_up = await self.detective.interrogate(name, suspect_response)
                log_file.write(f"{follow_up}\n\n")
                self.conversation_history.append(follow_up)
                self.case_file["interrogations"][name].append({
                    "speaker": "侦探",
                    "content": follow_up
                })
                
                # 嫌疑人的第二次回答
                suspect_response2 = await suspect.respond(follow_up.replace(f"{self.detective.name}: ", ""))
                log_file.write(f"{suspect_response2}\n\n")
                self.conversation_history.append(suspect_response2)
                self.case_file["interrogations"][name].append({
                    "speaker": name,
                    "content": suspect_response2
                })
                
                # 侦探的第三个问题
                third_question = await self.detective.interrogate(name, suspect_response2)
                log_file.write(f"{third_question}\n\n")
                self.conversation_history.append(third_question)
                self.case_file["interrogations"][name].append({
                    "speaker": "侦探",
                    "content": third_question
                })
                
                # 嫌疑人的第三次回答
                suspect_response3 = await suspect.respond(third_question.replace(f"{self.detective.name}: ", ""))
                log_file.write(f"{suspect_response3}\n\n")
                self.conversation_history.append(suspect_response3)
                self.case_file["interrogations"][name].append({
                    "speaker": name,
                    "content": suspect_response3
                })
            
            # 步骤4：侦探分析线索和证词
            log_file.write("=== 第四阶段：线索分析 ===\n\n")
            analysis = await self.detective.analyze_clues()
            log_file.write(f"{analysis}\n\n")
            self.conversation_history.append(analysis)
            self.case_file["investigation_log"].append({
                "phase": "线索分析",
                "content": analysis
            })
            
            # 步骤5：针对关键嫌疑人进行二次询问
            log_file.write("=== 第五阶段：二次询问 ===\n\n")
            
            # 二次询问格雷中士和桃小姐
            key_suspects = ["格雷中士", "桃小姐"]
            for name in key_suspects:
                log_file.write(f"--- 二次询问{name} ---\n\n")
                
                previous_answers = "\n".join([item["content"] for item in self.case_file["interrogations"][name] 
                                           if item["speaker"] == name])
                
                question = await self.detective.second_round_questioning(name, previous_answers)
                log_file.write(f"{question}\n\n")
                self.conversation_history.append(question)
                self.case_file["interrogations"][name].append({
                    "speaker": "侦探",
                    "content": question
                })
                
                suspect_response = await self.suspects[name].respond(question.replace(f"{self.detective.name}: ", ""))
                log_file.write(f"{suspect_response}\n\n")
                self.conversation_history.append(suspect_response)
                self.case_file["interrogations"][name].append({
                    "speaker": name,
                    "content": suspect_response
                })
            
            # 步骤6：侦探解决案件，给出最终结论
            log_file.write("=== 第六阶段：案件解决 ===\n\n")
            solution = await self.detective.solve_case()
            log_file.write(f"{solution}")
            self.conversation_history.append(solution)
            self.case_file["investigation_log"].append({
                "phase": "案件解决",
                "content": solution
            })
            self.case_file["conclusions"] = solution
            self.case_file["solved"] = True
        
        # 保存完整的案件文件
        case_file_path = f"{RESULTS_DIR}/case_file_{timestamp}.json"
        with open(case_file_path, 'w', encoding='utf-8') as f:
            json.dump(self.case_file, f, ensure_ascii=False, indent=2)
        
        print(f"调查已完成，详细记录已保存至 {case_log_file}")
        print(f"案件文件已保存至 {case_file_path}")
        
        # 关闭所有会话
        await self.ai_client.close_session()
        return case_log_file, case_file_path


async def main():
    # 请填入您的智谱AI API令牌
    api_token = "cb8a1ca3f10b4c53b1eb48658941cd7e.OheueJjqF7PtK4yW"
    api_url = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
    
    # 创建调度员并运行侦探调查
    dispatcher = Dispatcher(api_token=api_token, api_url=api_url, model="glm-z1-flash")
    case_log_file, case_file_path = await dispatcher.run_investigation()

if __name__ == "__main__":
    import time
    start_time = time.time()
    
    asyncio.run(main())
    
    end_time = time.time()
    print(f"总执行时间: {end_time - start_time:.2f} 秒")