import json
import asyncio
import aiohttp
import argparse
import logging
import os
import time
from tqdm.asyncio import tqdm as async_tqdm
from typing import List, Dict, Any, Optional
import random

# 导入改进的策略
from task2_prompt_strategy import (
    IMPROVED_STRATEGIES,
    MULTI_TURN_STRATEGIES,
    STRATEGY_GROUPS,
    generate_analysis_report
)

# 创建结果目录
RESULTS_DIR = "task2/results"
os.makedirs(RESULTS_DIR, exist_ok=True)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f"{RESULTS_DIR}/advanced_prompt_engineering.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def evaluate_response(response, solution):
    """Evaluate the match between the model response and the standard answer."""
    response_lower = response.lower()
    expected_answers = [f"{key}. {value}".lower() for key, value in solution.items()]
    all_correct = all(expected_answer in response_lower for expected_answer in expected_answers)
    accuracy = 1.0 if all_correct else 0.0
    return accuracy

def calculate_partial_score(response_lower, solution):
    """Calculate partial matching score based on the number of correct answers."""
    if not solution:
        return 0.0
    
    expected_answers = [f"{key}. {value}".lower() for key, value in solution.items()]
    matched = sum(1 for expected in expected_answers if expected in response_lower)
    return matched / len(expected_answers)

class AdvancedPromptEngineer:
    """增强版提示工程类，处理多种策略和多轮对话"""
    
    def __init__(
        self, 
        api_token: str,
        base_url: str = "https://open.bigmodel.cn/api/paas/v4/chat/completions",
        model: str = "glm-z1-flash",
        max_retries: int = 3,
        retry_delay: int = 1
    ):
        self.api_token = api_token
        self.base_url = base_url
        self.model = model
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.headers = {
            "Authorization": f"Bearer {self.api_token}", 
            "Content-Type": "application/json"
        }
    
    async def evaluate_strategy(
        self, 
        dataset: List[Dict], 
        strategy_name: str, 
        indices: List[int],
        concurrency: int = 3
    ) -> Dict[str, Any]:
        """评估单个策略在数据集上的效果"""
        is_multi_turn = strategy_name in MULTI_TURN_STRATEGIES
        
        # 确定使用哪种策略数据
        if strategy_name in IMPROVED_STRATEGIES:
            strategy_data = IMPROVED_STRATEGIES[strategy_name]
            system_prompt = strategy_data["system"]
            description = strategy_data["description"]
        elif strategy_name in MULTI_TURN_STRATEGIES:
            strategy_data = MULTI_TURN_STRATEGIES[strategy_name]
            # 多轮对话有不同的提示结构
            description = strategy_data["description"]
        else:
            # 未知策略
            logger.error(f"未知策略: {strategy_name}")
            return {
                "strategy": strategy_name,
                "results": [],
                "is_multi_turn": False,
                "error": "未知策略"
            }
        
        logger.info(f"评估策略: {strategy_name} ({description})")
        logger.info(f"使用模型: {self.model}")
        logger.info(f"样本数: {len(indices)}")
        
        # 准备并发任务
        semaphore = asyncio.Semaphore(concurrency)
        session = aiohttp.ClientSession()
        
        async def process_sample(idx: int):
            """处理单个样本的任务"""
            async with semaphore:
                item = dataset[idx]
                prompt = item["prompt"]
                solution = item["solution"]
                
                try:
                    if is_multi_turn:
                        # 多轮对话策略
                        result = await self._run_multi_turn_strategy(
                            strategy_name, prompt, solution, session
                        )
                    else:
                        # 单轮对话策略
                        result = await self._run_single_turn_strategy(
                            strategy_name, system_prompt, prompt, solution, session
                        )
                    
                    # 添加样本索引和策略信息
                    result["idx"] = idx
                    result["strategy"] = strategy_name
                    return result
                    
                except Exception as e:
                    logger.error(f"处理样本 {idx} 出错: {str(e)}")
                    return {
                        "idx": idx,
                        "strategy": strategy_name,
                        "prompt": prompt,
                        "solution": solution,
                        "success": False,
                        "error": f"处理异常: {str(e)}"
                    }
        
        # 创建处理任务
        tasks = [process_sample(idx) for idx in indices]
        
        # 执行并显示进度
        results = []
        try:
            for f in async_tqdm(
                asyncio.as_completed(tasks),
                total=len(tasks),
                desc=f"策略: {strategy_name}"
            ):
                result = await f
                results.append(result)
        except Exception as e:
            logger.error(f"执行测试任务出错: {str(e)}")
        finally:
            await session.close()
        
        # 计算整体指标
        successful_results = [r for r in results if r.get("success", False)]
        if successful_results:
            accuracy = sum(r.get("accuracy", 0) for r in successful_results) / len(successful_results)
            partial_score = sum(r.get("partial_score", 0) for r in successful_results) / len(successful_results)
            avg_latency = sum(r.get("latency", 0) for r in successful_results) / len(successful_results)
        else:
            accuracy = partial_score = avg_latency = 0
        
        logger.info(f"策略 {strategy_name} 评估完成:")
        logger.info(f"  准确率: {accuracy:.2%}")
        logger.info(f"  部分匹配分数: {partial_score:.2%}")
        logger.info(f"  平均延迟: {avg_latency:.2f}秒")
        
        return {
            "strategy": strategy_name,
            "description": description,
            "results": results,
            "is_multi_turn": is_multi_turn,
            "accuracy": accuracy,
            "partial_score": partial_score,
            "avg_latency": avg_latency
        }
    
    async def _run_single_turn_strategy(
        self, 
        strategy_name: str,
        system_prompt: str,
        user_prompt: str,
        solution: Dict[str, str],
        session: aiohttp.ClientSession
    ) -> Dict[str, Any]:
        """执行单轮对话策略"""
        result = {
            "strategy": strategy_name,
            "prompt": user_prompt,
            "solution": solution,
            "success": False,
            "single_turn": True
        }
        
        try:
            start_time = time.time()
            
            # 准备请求
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": user_prompt})
            
            # 发送请求
            api_response = await self._call_api(messages, session)
            end_time = time.time()
            result["latency"] = end_time - start_time
            
            if api_response.get("success", False):
                response_text = api_response["choices"][0]["message"]["content"]
                
                # 计算准确率
                accuracy = evaluate_response(response_text, solution)
                
                # 计算部分匹配分数
                response_lower = response_text.lower()
                partial_score = calculate_partial_score(response_lower, solution)
                
                # 更新结果
                result.update({
                    "success": True,
                    "response": response_text,
                    "accuracy": accuracy,
                    "partial_score": partial_score
                })
                
            else:
                # API调用失败
                result.update({
                    "success": False,
                    "error": api_response.get("error", "API调用失败，无具体错误")
                })
                
        except Exception as e:
            # 处理异常
            result.update({
                "success": False,
                "error": f"执行策略时出错: {str(e)}"
            })
        
        return result
        
    async def _run_multi_turn_strategy(
        self,
        strategy_name: str,
        user_prompt: str,
        solution: Dict[str, str],
        session: aiohttp.ClientSession
    ) -> Dict[str, Any]:
        """执行多轮对话策略"""
        strategy_data = MULTI_TURN_STRATEGIES[strategy_name]
        initial_prompt = strategy_data["initial_prompt"] + "\n\n" + user_prompt
        follow_up = strategy_data["follow_up"]
        
        result = {
            "strategy": strategy_name,
            "prompt": user_prompt,
            "solution": solution,
            "success": False,
            "multi_turn": True
        }
        
        try:
            start_time = time.time()
            
            # 第一轮对话
            messages = [{"role": "user", "content": initial_prompt}]
            first_response = await self._call_api(messages, session)
            
            if not first_response.get("success", False):
                # 第一轮失败
                result.update({
                    "success": False,
                    "error": first_response.get("error", "第一轮对话失败")
                })
                return result
            
            # 提取第一轮回复
            first_response_text = first_response["choices"][0]["message"]["content"]
            
            # 第二轮对话
            messages = [
                {"role": "user", "content": initial_prompt},
                {"role": "assistant", "content": first_response_text},
                {"role": "user", "content": follow_up}
            ]
            
            second_response = await self._call_api(messages, session)
            end_time = time.time()
            result["latency"] = end_time - start_time
            
            if second_response.get("success", False):
                # 提取第二轮回复
                second_response_text = second_response["choices"][0]["message"]["content"]
                
                # 计算准确率
                accuracy = evaluate_response(second_response_text, solution)
                
                # 计算部分匹配分数
                response_lower = second_response_text.lower()
                partial_score = calculate_partial_score(response_lower, solution)
                
                # 更新结果
                result.update({
                    "success": True,
                    "first_turn_response": first_response_text,
                    "response": second_response_text,
                    "accuracy": accuracy,
                    "partial_score": partial_score
                })
            else:
                # 第二轮失败但第一轮成功
                # 尝试用第一轮回复评估
                accuracy = evaluate_response(first_response_text, solution)
                response_lower = first_response_text.lower()
                partial_score = calculate_partial_score(response_lower, solution)
                
                result.update({
                    "success": True,  # 第一轮已成功
                    "first_turn_response": first_response_text,
                    "response": first_response_text,  # 使用第一轮回复作为最终回复
                    "accuracy": accuracy,
                    "partial_score": partial_score,
                    "second_turn_error": second_response.get("error", "第二轮对话失败")
                })
                
        except Exception as e:
            # 处理异常
            result.update({
                "success": False,
                "error": f"执行多轮策略时出错: {str(e)}"
            })
        
        return result
    
    async def _call_api(self, messages: List[Dict], session: aiohttp.ClientSession) -> Dict[str, Any]:
        """调用智谱API并处理重试"""
        max_delay = 32  # 最大重试延迟
        current_delay = self.retry_delay
        
        for attempt in range(self.max_retries):
            try:
                # 准备请求体
                body = {
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                    "temperature": 0.2,  # 降低温度以提高一致性
                    "max_tokens": 4096,
                }
                
                # 发送请求
                async with session.post(
                    self.base_url, 
                    headers=self.headers, 
                    json=body
                ) as response:
                    response.raise_for_status()
                    response_data = await response.json()
                    
                    return {
                        "success": True,
                        **response_data
                    }
                    
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                error_msg = f"API调用错误(尝试 {attempt+1}/{self.max_retries}): {str(e)}"
                logger.warning(error_msg)
                
                if attempt == self.max_retries - 1:
                    # 最后一次尝试也失败
                    return {
                        "success": False,
                        "error": error_msg
                    }
                
                # 指数退避重试
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, max_delay)
                
            except Exception as e:
                # 其他异常
                error_msg = f"未预期的错误: {str(e)}"
                logger.error(error_msg)
                return {
                    "success": False,
                    "error": error_msg
                }
        
        # 不应该到这里
        return {
            "success": False,
            "error": "达到最大重试次数"
        }
    
    async def compare_strategies(
        self,
        dataset: List[Dict],
        strategies: List[str],
        indices: List[int],
        concurrency: int = 3
    ) -> Dict[str, Any]:
        """比较多种策略的效果"""
        all_results = {}
        strategy_metrics = {}
        
        # 逐一评估每个策略
        for strategy in strategies:
            logger.info(f"评估策略 {strategy} 中...")
            
            result = await self.evaluate_strategy(
                dataset=dataset,
                strategy_name=strategy,
                indices=indices,
                concurrency=concurrency
            )
            
            all_results[strategy] = result["results"]
            
            # 收集评估指标
            if result.get("success", True):  # 没有明确失败就认为策略评估成功
                strategy_metrics[strategy] = {
                    "accuracy": result.get("accuracy", 0),
                    "partial_score": result.get("partial_score", 0),
                    "avg_latency": result.get("avg_latency", 0),
                    "description": result.get("description", ""),
                    "is_multi_turn": result.get("is_multi_turn", False)
                }
        
        # 生成比较分析报告
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        report_path = f"{RESULTS_DIR}/strategy_analysis_{self.model}_{timestamp}.md"
        analysis_report = generate_analysis_report(strategy_metrics, report_path)
        
        return {
            "all_results": all_results,
            "strategy_metrics": strategy_metrics,
            "analysis_report": analysis_report
        }

async def main():
    parser = argparse.ArgumentParser(description="高级提示工程评估工具")
    parser.add_argument("--api-token", type=str, default="cb8a1ca3f10b4c53b1eb48658941cd7e.OheueJjqF7PtK4yW", help="智谱API密钥")
    parser.add_argument("--model", type=str, default="glm-z1-flash", 
                      choices=["glm-z1-air", "glm-z1-airx", "glm-z1-flash"],
                      help="选择要使用的模型")
    parser.add_argument("--dataset", type=str, default="data/tc_200_zh.json", help="数据集路径")
    parser.add_argument("--range", type=str, default="0-199", 
                      help="要测试的数据集索引范围，格式如'0-9'或'0|5|10'")
    parser.add_argument("--concurrency", type=int, default=3, help="并发请求数量")
    parser.add_argument("--strategies", type=str, default="", 
                      help="要测试的策略，以逗号分隔，留空测试所有策略")
    parser.add_argument("--group", type=str, default="", 
                      help="要测试的策略组，与--strategies互斥")
    
    args = parser.parse_args()
    
    try:
        # 加载数据集
        logger.info(f"加载数据集: {args.dataset}")
        with open(args.dataset, "r", encoding="utf-8") as f:
            dataset = json.load(f)
        
        # 解析索引范围
        indices = []
        parts = args.range.split("|")
        for part in parts:
            if "-" in part:
                start, end = map(int, part.split("-"))
                indices.extend(range(start, min(end + 1, len(dataset))))
            else:
                try:
                    idx = int(part)
                    if 0 <= idx < len(dataset):
                        indices.append(idx)
                except ValueError:
                    pass
        
        indices = sorted(list(set(indices)))
        if not indices:
            logger.warning("无效的数据范围，使用默认范围0-9")
            indices = list(range(min(10, len(dataset))))
        
        logger.info(f"将处理 {len(indices)} 个样本: {indices}")
        
        # 确定要测试的策略
        test_strategies = []
        if args.group:
            # 使用预定义策略组
            if args.group in STRATEGY_GROUPS:
                test_strategies = STRATEGY_GROUPS[args.group]
                logger.info(f"使用策略组 '{args.group}': {test_strategies}")
            else:
                available_groups = ", ".join(STRATEGY_GROUPS.keys())
                logger.error(f"未知策略组: '{args.group}'。可用组: {available_groups}")
                return
        elif args.strategies:
            # 使用指定策略列表
            test_strategies = [s.strip() for s in args.strategies.split(",")]
            logger.info(f"使用指定策略: {test_strategies}")
        else:
            # 默认测试所有改进策略和一个多轮策略
            test_strategies = list(IMPROVED_STRATEGIES.keys()) + ["reflect_correct"]
            logger.info(f"使用默认策略集: {test_strategies}")
        
        # 创建提示工程评估器
        prompt_engineer = AdvancedPromptEngineer(
            api_token=args.api_token,
            model=args.model,
            max_retries=3
        )
        
        # 比较策略
        results = await prompt_engineer.compare_strategies(
            dataset=dataset,
            strategies=test_strategies,
            indices=indices,
            concurrency=args.concurrency
        )
        
        # 保存结果
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        results_file = f"{RESULTS_DIR}/strategy_results_{args.model}_{timestamp}.json"
        
        with open(results_file, "w", encoding="utf-8") as f:
            # 只保存metrics部分，all_results可能过大
            json.dump({
                "model": args.model,
                "dataset": args.dataset,
                "indices": indices,
                "strategies": test_strategies,
                "strategy_metrics": results["strategy_metrics"],
                "timestamp": timestamp
            }, f, ensure_ascii=False, indent=2)
        
        logger.info(f"结果已保存至: {results_file}")
        
    except Exception as e:
        logger.exception(f"运行出错: {str(e)}")

if __name__ == "__main__":
    asyncio.run(main())