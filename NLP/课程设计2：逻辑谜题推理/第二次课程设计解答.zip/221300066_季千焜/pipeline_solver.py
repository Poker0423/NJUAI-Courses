import json
import asyncio
import aiohttp
import argparse
import logging
import os
import time
import re
import traceback
from datetime import datetime
from typing import List, Dict, Any, Optional, Set, Tuple
from tqdm import tqdm
from ortools.sat.python import cp_model
import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pipeline_solver.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# 确保相关目录存在
RESULTS_DIR = "task3/results"
DATA_DIR = "task3/data"
INTERIM_DIR = f"{DATA_DIR}/interim"
PROCESSED_DIR = f"{DATA_DIR}/processed"

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(INTERIM_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)

class EntityCleaner:
    """使用GLM-4-Flash清理和优化提取的实体"""
    
    def __init__(self, api_token: str, api_url: str = "https://open.bigmodel.cn/api/paas/v4/chat/completions"):
        self.api_token = api_token
        self.api_url = api_url
        self.headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}
        self._session = None
    
    async def get_session(self) -> aiohttp.ClientSession:
        """获取或创建HTTP会话"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    async def close_session(self):
        """关闭HTTP会话"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    async def clean_entities(self, puzzle_text: str, raw_entities: Dict) -> Dict:
        """清理和优化提取的实体"""
        system_prompt = """你是一位精确的逻辑谜题分析专家。你的任务是检查从谜题中提取的实体，去除错误识别的内容，并提供准确的实体列表。

请注意以下规则：
1. 嫌疑人应该是人名，通常带有"先生"、"小姐"、"夫人"、"教授"等称谓
2. 武器应该是具体的物品，如"刀"、"枪"、"绳索"等
3. 地点应该是具体的房间或场所，如"大厅"、"书房"、"花园"等
4. 去除那些明显是线索而非实体的文本，特别是含有时间、方向描述或关系描述的文本
5. 去除重复的实体，保持列表简洁
6. 确保实体名称简短准确，删除不必要的修饰词

请以下面的JSON格式返回清理后的实体：
```json
{
  "suspects": ["嫌疑人1", "嫌疑人2", ...],
  "weapons": ["武器1", "武器2", ...],
  "locations": ["地点1", "地点2", ...]
}
```
只返回JSON内容，不要添加任何额外说明。"""

        # 准备初始实体信息
        suspects = raw_entities.get("suspects", [])
        weapons = raw_entities.get("weapons", [])
        locations = raw_entities.get("locations", [])
        
        user_prompt = f"""请分析以下谜题并清理提取的实体：

谜题：
{puzzle_text}

初步提取的实体：
嫌疑人: {suspects}
武器: {weapons}
地点: {locations}

请清理这些实体，去除错误识别的内容，保留真正的嫌疑人、武器和地点。"""

        try:
            session = await self.get_session()
            
            payload = {
                "model": "glm-4-flash-250414",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                "temperature": 0.1,
                "stream": False
            }
            
            async with session.post(self.api_url, headers=self.headers, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"GLM-4-Flash API调用失败: {response.status} - {error_text}")
                    return raw_entities
                
                data = await response.json()
                content = data["choices"][0]["message"]["content"]
                
                # 尝试解析JSON
                try:
                    # 查找JSON内容
                    if "```json" in content:
                        json_str = content.split("```json")[1].split("```")[0].strip()
                    elif "```" in content:
                        json_str = content.split("```")[1].strip()
                    else:
                        json_str = content.strip()
                    
                    # 解析JSON
                    cleaned_entities = json.loads(json_str)
                    
                    # 记录清理结果
                    logger.info(f"清理后的嫌疑人: {cleaned_entities.get('suspects', [])}")
                    logger.info(f"清理后的武器: {cleaned_entities.get('weapons', [])}")
                    logger.info(f"清理后的地点: {cleaned_entities.get('locations', [])}")
                    
                    return cleaned_entities
                
                except json.JSONDecodeError:
                    logger.error(f"无法解析GLM-4-Flash返回的JSON: {content}")
                    return raw_entities
                except Exception as e:
                    logger.error(f"处理GLM-4-Flash响应时出错: {str(e)}")
                    return raw_entities
        
        except Exception as e:
            logger.error(f"调用GLM-4-Flash API时出错: {str(e)}")
            return raw_entities

            
class LogicUtils:
    """逻辑求解工具集"""
    
    @staticmethod
    def extract_entities(puzzle_text: str) -> Dict:
        """提取实体（嫌疑人、凶器、地点等）"""
        try:
            suspects = []
            weapons = []
            locations = []
            times = []
            motives = []
            
            # 提取嫌疑人
            suspect_patterns = [
                r'嫌疑人[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)',
                r'(?:以下|下列)(?:人物|嫌疑人)[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)'
            ]
            
            for pattern in suspect_patterns:
                match = re.search(pattern, puzzle_text, re.DOTALL)
                if match:
                    suspects_text = match.group(1)
                    suspects = re.findall(r'(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十][\.、]?)\s*([^\n•\*\-]+)', suspects_text)
                    suspects = [s.strip() for s in suspects]
                    break
            
            # 如果正则表达式没有找到嫌疑人，尝试其他方法
            if not suspects:
                name_patterns = [
                    r'([A-Z][a-z]*(?:\s[A-Z][a-z]*)?先生)',
                    r'([A-Z][a-z]*(?:\s[A-Z][a-z]*)?夫人)',
                    r'([A-Z][a-z]*(?:\s[A-Z][a-z]*)?小姐)',
                    r'([\u4e00-\u9fa5]{1,3}(?:先生|夫人|小姐|教授|上校|女士|医生))'
                ]
                
                for pattern in name_patterns:
                    suspects = re.findall(pattern, puzzle_text)
                    if suspects:
                        suspects = list(set(suspects))  # 去重
                        break
            
            # 提取凶器/武器
            weapon_patterns = [
                r'(?:凶器|武器)[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)',
                r'(?:以下|下列)(?:物品|武器|凶器)[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)'
            ]
            
            for pattern in weapon_patterns:
                match = re.search(pattern, puzzle_text, re.DOTALL)
                if match:
                    weapons_text = match.group(1)
                    weapons = re.findall(r'(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十][\.、]?)\s*([^\n•\*\-]+)', weapons_text)
                    weapons = [w.strip() for w in weapons]
                    break
            
            # 如果正则表达式没有找到武器，尝试在文本中查找常见武器
            if not weapons:
                common_weapons = ["匕首", "刀", "手枪", "左轮手枪", "枪", "绳索", "铅管", "烛台", "扳手", "毒药", "撬棍"]
                weapons = [w for w in common_weapons if w in puzzle_text]
            
            # 提取地点
            location_patterns = [
                r'(?:地点|位置|房间)(?:包括)?[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)',
                r'(?:以下|下列)(?:地点|房间|位置)[:：]?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)',
                r'命案现场[^。\n]*(?:只可能|可能)(?:是|位于|在)以下[^。\n]*?(?:其中)?\s*((?:(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十])[^•\*\-\n]*\n?)+)'
            ]
            
            for pattern in location_patterns:
                match = re.search(pattern, puzzle_text, re.DOTALL)
                if match:
                    locations_text = match.group(1)
                    locations = re.findall(r'(?:•|\*|-|[A-Za-z0-9一二三四五六七八九十][\.、]?)\s*([^\n•\*\-]+)', locations_text)
                    locations = [l.strip() for l in locations]
                    break
            
            # 如果正则表达式没有找到地点，尝试在文本中查找常见地点
            if not locations:
                common_locations = ["大厅", "厨房", "书房", "卧室", "花园", "客厅", "餐厅", "地下室", "图书馆", "马车房"]
                locations = [l for l in common_locations if l in puzzle_text]
            
            # 提取时间
            time_matches = re.findall(r'(\d{1,2}[:：]\d{2})', puzzle_text)
            times = [t.replace('：', ':') for t in time_matches]
            
            # 提取可能的动机
            common_motives = ["嫉妒", "仇恨", "贪婪", "复仇", "恐惧", "爱情", "钱财", "野心"]
            motives = [m for m in common_motives if m in puzzle_text]
            
            # 记录提取的实体
            logger.info(f"提取到的嫌疑人: {suspects}")
            logger.info(f"提取到的武器: {weapons}")
            logger.info(f"提取到的地点: {locations}")
            
            return {
                "success": True,
                "suspects": suspects,
                "weapons": weapons,
                "locations": locations,
                "times": times,
                "motives": motives
            }
        except Exception as e:
            logger.error(f"提取实体时出错: {str(e)}\n{traceback.format_exc()}")
            return {
                "success": False,
                "error": f"提取实体时出错: {str(e)}",
                "suspects": [],
                "weapons": [],
                "locations": [],
                "times": [],
                "motives": []
            }
    
    @staticmethod
    def extract_clues(puzzle_text: str) -> Dict:
        """提取线索"""
        try:
            # 尝试找到线索段落
            clue_section = ""
            clue_patterns = [
                r"线索[:：]?\s*((?:[^\n]*\n?)+)",
                r"已知(?:条件|线索)?[:：]?\s*((?:[^\n]*\n?)+)",
                r"(?:根据|经过).*?线索.*?[:：]?\s*((?:[^\n]*\n?)+)",
                r"线索(?:缓缓)?浮出水面[:：]?\s*((?:[^\n]*\n?)+)"
            ]
            
            for pattern in clue_patterns:
                match = re.search(pattern, puzzle_text, re.DOTALL)
                if match:
                    clue_section = match.group(1)
                    break
            
            # 如果没找到线索段落，尝试提取带标记的行
            clues = []
            if clue_section:
                # 尝试按行分割，识别标记
                lines = clue_section.split('\n')
                for line in lines:
                    line = line.strip()
                    if line and not line.isspace():
                        # 移除行首的编号或标记
                        line = re.sub(r'^(\d+\.|\-|\•|\*)\s*', '', line)
                        if line:
                            clues.append(line)
            else:
                # 尝试匹配带有标记的行
                bullet_clues = re.findall(r'(?:^|\n)(?:\d+\.|\-|\•|\*)\s*([^\n]+)', puzzle_text)
                clues = [c.strip() for c in bullet_clues if c.strip()]
            
            # 如果以上方法都无法找到线索，尝试将整个文本拆分为句子，选择可能的线索
            if not clues:
                sentences = re.split(r'(?<=[。.！!？?])\s*', puzzle_text)
                potential_clues = []
                
                key_phrases = ["如果", "不可能", "必须", "一定", "在", "是", "不是", "凶手", "凶器", "地点", "嫌疑人"]
                for sent in sentences:
                    sent = sent.strip()
                    if sent and any(phrase in sent for phrase in key_phrases):
                        potential_clues.append(sent)
                
                if potential_clues:
                    clues = potential_clues
            
            logger.info(f"提取到 {len(clues)} 条线索")
            return {
                "success": True,
                "clues": clues,
                "count": len(clues)
            }
        except Exception as e:
            logger.error(f"提取线索时出错: {str(e)}\n{traceback.format_exc()}")
            return {
                "success": False,
                "error": f"提取线索时出错: {str(e)}",
                "clues": [],
                "count": 0
            }
    
    @staticmethod
    def analyze_constraint(clue: str, entities: Dict) -> Dict:
        """分析单条线索的逻辑约束"""
        try:
            # 获取实体列表
            suspects = entities.get("suspects", [])
            weapons = entities.get("weapons", [])
            locations = entities.get("locations", [])
            
            # 1. 检测肯定约束 (X是凶手/凶器/地点)
            for suspect in suspects:
                if re.search(f"{suspect}(?:就|是|为|一定是|肯定是)(?:凶手|嫌疑人|犯人|真凶)", clue):
                    return {
                        "success": True,
                        "type": "positive",
                        "entity_type": "suspect",
                        "value": suspect,
                        "explanation": f"{suspect}是凶手"
                    }
            
            for weapon in weapons:
                if re.search(f"{weapon}(?:就|是|为|一定是|肯定是)(?:凶器|作案工具|武器)", clue) or \
                   re.search(f"(?:凶器|作案工具|武器)(?:就|是|为|一定是|肯定是){weapon}", clue):
                    return {
                        "success": True,
                        "type": "positive",
                        "entity_type": "weapon",
                        "value": weapon,
                        "explanation": f"{weapon}是凶器"
                    }
            
            for location in locations:
                if re.search(f"(?:案发|犯罪|命案)(?:地点|现场|位置|房间)(?:就|是|为|一定是|肯定是){location}", clue) or \
                   re.search(f"{location}(?:就|是|为|一定是|肯定是)(?:案发|犯罪|命案)(?:地点|现场|位置|房间)", clue):
                    return {
                        "success": True,
                        "type": "positive",
                        "entity_type": "location",
                        "value": location,
                        "explanation": f"{location}是案发地点"
                    }
            
            # 2. 检测否定约束 (X不是凶手/凶器/地点)
            for suspect in suspects:
                if re.search(f"{suspect}(?:不是|不可能是|不会是)(?:凶手|嫌疑人|犯人|真凶)", clue):
                    return {
                        "success": True,
                        "type": "negative",
                        "entity_type": "suspect",
                        "value": suspect,
                        "explanation": f"{suspect}不是凶手"
                    }
            
            for weapon in weapons:
                if re.search(f"{weapon}(?:不是|不可能是|不会是)(?:凶器|作案工具|武器)", clue) or \
                   re.search(f"(?:凶器|作案工具|武器)(?:不是|不可能是|不会是){weapon}", clue):
                    return {
                        "success": True,
                        "type": "negative",
                        "entity_type": "weapon",
                        "value": weapon,
                        "explanation": f"{weapon}不是凶器"
                    }
            
            for location in locations:
                if re.search(f"(?:案发|犯罪|命案)(?:地点|现场|位置|房间)(?:不是|不可能是|不会是){location}", clue) or \
                   re.search(f"{location}(?:不是|不可能是|不会是)(?:案发|犯罪|命案)(?:地点|现场|位置|房间)", clue):
                    return {
                        "success": True,
                        "type": "negative",
                        "entity_type": "location",
                        "value": location,
                        "explanation": f"{location}不是案发地点"
                    }
            
            # 3. 检测条件约束 (如果...那么...)
            if_then_match = re.search(r"如果(.+?)，(?:那么|则)(.+)", clue)
            if if_then_match:
                condition = if_then_match.group(1).strip()
                conclusion = if_then_match.group(2).strip()
                
                # 识别条件和结论中的实体
                condition_entity = LogicUtils._find_entity_in_text(condition, suspects, weapons, locations)
                conclusion_entity = LogicUtils._find_entity_in_text(conclusion, suspects, weapons, locations)
                
                if condition_entity and conclusion_entity:
                    return {
                        "success": True,
                        "type": "conditional",
                        "condition": {
                            "type": condition_entity["type"],
                            "value": condition_entity["value"]
                        },
                        "conclusion": {
                            "type": conclusion_entity["type"],
                            "value": conclusion_entity["value"]
                        },
                        "explanation": f"如果{condition_entity['value']}，那么{conclusion_entity['value']}"
                    }
            
            # 4. 检测位置关系约束
            for suspect in suspects:
                for location in locations:
                    if re.search(f"{suspect}.*?(?:在|位于|处于){location}", clue):
                        return {
                            "success": True,
                            "type": "location",
                            "entity1_type": "suspect",
                            "entity1_value": suspect,
                            "entity2_type": "location",
                            "entity2_value": location,
                            "explanation": f"{suspect}位于{location}"
                        }
            
            # 5. 检查特定词汇的约束
            for weapon in weapons:
                if "致命" in clue and weapon in clue:
                    return {
                        "success": True,
                        "type": "positive",
                        "entity_type": "weapon",
                        "value": weapon,
                        "explanation": f"致命伤来自{weapon}"
                    }
            
            # 6. 检测方向关系
            directions = ["北", "南", "东", "西"]
            for suspect in suspects:
                for location in locations:
                    for direction in directions:
                        if re.search(f"{suspect}.*?(?:在|位于){location}的{direction}方", clue):
                            return {
                                "success": True,
                                "type": "directional",
                                "entity1_type": "suspect",
                                "entity1_value": suspect,
                                "entity2_type": "location",
                                "entity2_value": location,
                                "direction": direction,
                                "explanation": f"{suspect}位于{location}的{direction}方"
                            }
            
            # 没有匹配到任何约束类型
            return {
                "success": True,
                "type": "unknown",
                "explanation": "无法解析该线索的具体约束类型",
                "original_clue": clue
            }
        except Exception as e:
            logger.error(f"分析约束时出错: {str(e)}\n{traceback.format_exc()}")
            return {
                "success": False,
                "error": f"分析约束时出错: {str(e)}",
                "type": "error",
                "explanation": f"分析出错: {str(e)}"
            }
    
    @staticmethod
    def solve_with_cp_sat(entities: Dict, constraints: List[Dict]) -> Dict:
        """使用CP-SAT求解器解决逻辑谜题"""
        try:
            # 获取实体列表
            suspects = entities.get("suspects", [])
            weapons = entities.get("weapons", [])
            locations = entities.get("locations", [])
            
            # 如果没有足够的实体，返回错误
            if len(suspects) == 0 or len(weapons) == 0 or len(locations) == 0:
                return {
                    "success": False,
                    "error": "实体数量不足，无法求解",
                    "solution": {
                        "A": "未知",
                        "B": "未知",
                        "C": "未知"
                    }
                }
            
            logger.info(f"使用CP-SAT求解: {len(suspects)}个嫌疑人, {len(weapons)}个武器, {len(locations)}个地点, {len(constraints)}个约束")
            
            # 创建CP-SAT模型
            model = cp_model.CpModel()
            
            # 1. 创建变量
            # 嫌疑人变量：suspect_vars[s] = 1 表示嫌疑人s是凶手
            suspect_vars = {}
            for s in suspects:
                suspect_vars[s] = model.NewBoolVar(f"suspect_{s}")
            
            # 武器变量：weapon_vars[w] = 1 表示武器w是凶器
            weapon_vars = {}
            for w in weapons:
                weapon_vars[w] = model.NewBoolVar(f"weapon_{w}")
            
            # 地点变量：location_vars[l] = 1 表示地点l是案发地点
            location_vars = {}
            for l in locations:
                location_vars[l] = model.NewBoolVar(f"location_{l}")
            
            # 2. 添加基本约束：必须有且只有一个凶手、一件凶器、一个案发地点
            model.Add(sum(suspect_vars.values()) == 1)
            model.Add(sum(weapon_vars.values()) == 1)
            model.Add(sum(location_vars.values()) == 1)
            
            # 3. 处理位置矩阵（谁在哪里）
            suspect_at_location = {}
            for s in suspects:
                for l in locations:
                    suspect_at_location[(s, l)] = model.NewBoolVar(f"suspect_{s}_at_{l}")
            
            # 每个嫌疑人必须在某个地点
            for s in suspects:
                model.Add(sum(suspect_at_location[(s, l)] for l in locations) == 1)
            
            # 武器在地点的矩阵
            weapon_at_location = {}
            for w in weapons:
                for l in locations:
                    weapon_at_location[(w, l)] = model.NewBoolVar(f"weapon_{w}_at_{l}")
            
            # 每个武器必须在某个地点
            for w in weapons:
                model.Add(sum(weapon_at_location[(w, l)] for l in locations) == 1)
            
            # 4. 应用约束条件
            for constraint in constraints:
                constraint_type = constraint.get("type", "")
                
                # 肯定约束（某人是凶手、某物是凶器、某地是案发地点）
                if constraint_type == "positive":
                    entity_type = constraint.get("entity_type", "")
                    value = constraint.get("value", "")
                    
                    if entity_type == "suspect" and value in suspect_vars:
                        model.Add(suspect_vars[value] == 1)
                        logger.info(f"添加约束: {value}是凶手")
                    
                    elif entity_type == "weapon" and value in weapon_vars:
                        model.Add(weapon_vars[value] == 1)
                        logger.info(f"添加约束: {value}是凶器")
                    
                    elif entity_type == "location" and value in location_vars:
                        model.Add(location_vars[value] == 1)
                        logger.info(f"添加约束: {value}是案发地点")
                
                # 否定约束（某人不是凶手、某物不是凶器、某地不是案发地点）
                elif constraint_type == "negative":
                    entity_type = constraint.get("entity_type", "")
                    value = constraint.get("value", "")
                    
                    if entity_type == "suspect" and value in suspect_vars:
                        model.Add(suspect_vars[value] == 0)
                        logger.info(f"添加约束: {value}不是凶手")
                    
                    elif entity_type == "weapon" and value in weapon_vars:
                        model.Add(weapon_vars[value] == 0)
                        logger.info(f"添加约束: {value}不是凶器")
                    
                    elif entity_type == "location" and value in location_vars:
                        model.Add(location_vars[value] == 0)
                        logger.info(f"添加约束: {value}不是案发地点")
                
                # 条件约束（如果A，那么B）
                elif constraint_type == "conditional":
                    condition = constraint.get("condition", {})
                    conclusion = constraint.get("conclusion", {})
                    
                    condition_type = condition.get("type", "")
                    condition_value = condition.get("value", "")
                    conclusion_type = conclusion.get("type", "")
                    conclusion_value = conclusion.get("value", "")
                    
                    # 获取条件变量
                    condition_var = None
                    if condition_type == "suspect" and condition_value in suspect_vars:
                        condition_var = suspect_vars[condition_value]
                    elif condition_type == "weapon" and condition_value in weapon_vars:
                        condition_var = weapon_vars[condition_value]
                    elif condition_type == "location" and condition_value in location_vars:
                        condition_var = location_vars[condition_value]
                    
                    # 获取结论变量
                    conclusion_var = None
                    if conclusion_type == "suspect" and conclusion_value in suspect_vars:
                        conclusion_var = suspect_vars[conclusion_value]
                    elif conclusion_type == "weapon" and conclusion_value in weapon_vars:
                        conclusion_var = weapon_vars[conclusion_value]
                    elif conclusion_type == "location" and conclusion_value in location_vars:
                        conclusion_var = location_vars[conclusion_value]
                    
                    # 添加条件约束
                    if condition_var and conclusion_var:
                        model.AddImplication(condition_var, conclusion_var)
                        logger.info(f"添加约束: 如果{condition_value}，那么{conclusion_value}")
                
                # 位置约束（某人在某地点）
                elif constraint_type == "location":
                    entity1_type = constraint.get("entity1_type", "")
                    entity1_value = constraint.get("entity1_value", "")
                    entity2_type = constraint.get("entity2_type", "")
                    entity2_value = constraint.get("entity2_value", "")
                    
                    if entity1_type == "suspect" and entity2_type == "location":
                        if (entity1_value, entity2_value) in suspect_at_location:
                            model.Add(suspect_at_location[(entity1_value, entity2_value)] == 1)
                            logger.info(f"添加约束: {entity1_value}位于{entity2_value}")
            
            # 5. 求解
            solver = cp_model.CpSolver()
            status = solver.Solve(model)
            
            # 6. 处理结果
            if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
                # 找出是凶手的嫌疑人
                the_suspect = None
                for s, var in suspect_vars.items():
                    if solver.Value(var) == 1:
                        the_suspect = s
                        break
                
                # 找出是凶器的武器
                the_weapon = None
                for w, var in weapon_vars.items():
                    if solver.Value(var) == 1:
                        the_weapon = w
                        break
                
                # 找出是案发地点的位置
                the_location = None
                for l, var in location_vars.items():
                    if solver.Value(var) == 1:
                        the_location = l
                        break
                
                # 记录嫌疑人位置
                suspect_locations = {}
                for s in suspects:
                    for l in locations:
                        if (s, l) in suspect_at_location and solver.Value(suspect_at_location[(s, l)]) == 1:
                            suspect_locations[s] = l
                
                # 记录武器位置
                weapon_locations = {}
                for w in weapons:
                    for l in locations:
                        if (w, l) in weapon_at_location and solver.Value(weapon_at_location[(w, l)]) == 1:
                            weapon_locations[w] = l
                
                logger.info(f"求解成功: 凶手={the_suspect}, 凶器={the_weapon}, 地点={the_location}")
                
                # 构建结果
                return {
                    "success": True,
                    "suspect": the_suspect,
                    "weapon": the_weapon,
                    "location": the_location,
                    "suspect_locations": suspect_locations,
                    "weapon_locations": weapon_locations,
                    "solution": {
                        "A": the_suspect,
                        "B": the_weapon,
                        "C": the_location
                    }
                }
            else:
                logger.warning(f"求解失败，状态码: {status}")
                return {
                    "success": False,
                    "error": f"无法找到符合所有约束的解，状态码: {status}",
                    "solution": {
                        "A": "未知",
                        "B": "未知",
                        "C": "未知"
                    }
                }
                
        except Exception as e:
            logger.error(f"CP-SAT求解出错: {str(e)}\n{traceback.format_exc()}")
            return {
                "success": False,
                "error": f"求解过程出错: {str(e)}",
                "solution": {
                    "A": "未知",
                    "B": "未知",
                    "C": "未知"
                }
            }
    
    @staticmethod
    def _find_entity_in_text(text: str, suspects: List[str], weapons: List[str], locations: List[str]) -> Optional[Dict]:
        """在文本中查找实体"""
        # 确保是字符串
        if not isinstance(text, str):
            return None
            
        # 先检查嫌疑人
        for suspect in suspects:
            if suspect in text:
                return {"type": "suspect", "value": suspect}
        
        # 再检查武器
        for weapon in weapons:
            if weapon in text:
                return {"type": "weapon", "value": weapon}
        
        # 最后检查地点
        for location in locations:
            if location in text:
                return {"type": "location", "value": location}
        
        return None

class PipelineSolver:
    """管道式谜题求解器"""
    
    def __init__(self, api_token: str, api_url: str, model: str, glm4_token: str = None):
        self.api_token = api_token
        self.api_url = api_url
        self.model = model
        self.headers = {"Authorization": f"Bearer {self.api_token}", "Content-Type": "application/json"}
        self._session = None
        
        # 初始化实体清理器
        self.entity_cleaner = None
        if glm4_token:
            self.entity_cleaner = EntityCleaner(glm4_token)

    
    async def get_session(self) -> aiohttp.ClientSession:
        """获取或创建HTTP会话"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    async def close_session(self):
        """关闭HTTP会话"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    async def call_api(self, messages: List[Dict]) -> Dict:
        """调用LLM API"""
        session = await self.get_session()
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 4000,
            "stream": False
        }
        
        try:
            async with session.post(self.api_url, headers=self.headers, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"success": True, "data": data}
                else:
                    error_text = await response.text()
                    logger.error(f"API调用失败: HTTP {response.status} - {error_text}")
                    return {"success": False, "error": f"HTTP错误 {response.status}: {error_text}"}
        except Exception as e:
            logger.error(f"调用API出错: {str(e)}")
            return {"success": False, "error": f"调用API异常: {str(e)}"}
    
    async def process_initial_prompt(self, prompt: str) -> Dict:
        """第1步：初步处理谜题提示，提取关键信息"""
        system_prompt = """你是一位精确的逻辑推理专家，我会给你一个逻辑谜题。请分析这个谜题并提取以下信息：

1. 所有可能的嫌疑人列表
2. 所有可能的凶器/武器列表
3. 所有可能的案发地点列表
4. 所有线索列表

请按照以下JSON格式返回，不要添加任何其他内容：
```
{
  "suspects": ["嫌疑人1", "嫌疑人2", ...],
  "weapons": ["凶器1", "凶器2", ...],
  "locations": ["地点1", "地点2", ...],
  "clues": ["线索1", "线索2", ...]
}
```
"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
        
        api_response = await self.call_api(messages)
        
        if not api_response.get("success", False):
            return {
                "success": False,
                "error": api_response.get("error", "API调用失败")
            }
        
        # 处理响应
        try:
            response_data = api_response["data"]
            assistant_message = response_data["choices"][0]["message"]
            content = assistant_message.get("content", "")
            
            # 尝试提取JSON
            json_match = re.search(r'```(?:json)?(.*?)```', content, re.DOTALL)
            if json_match:
                json_str = json_match.group(1).strip()
                return {
                    "success": True,
                    "initial_data": json.loads(json_str)
                }
            else:
                # 尝试直接解析整个内容为JSON
                try:
                    return {
                        "success": True,
                        "initial_data": json.loads(content)
                    }
                except:
                    return {
                        "success": False,
                        "error": "无法从API响应中解析JSON",
                        "content": content
                    }
        
        except Exception as e:
            logger.error(f"处理API响应时出错: {str(e)}")
            return {
                "success": False,
                "error": f"处理API响应时出错: {str(e)}"
            }
    
    async def generate_final_answer(self, prompt: str, solution_data: Dict) -> Dict:
        """最后一步：生成最终答案"""
        # 构建提示
        system_prompt = """你是一位精确的逻辑推理专家。我已经为你提供了一个谜题和求解结果，请你检查这个结果并生成最终的答案。

请按照以下格式给出答案，确保每项单独一行，不要添加额外解释：

A. [凶手/嫌疑人]
B. [凶器/武器]
C. [案发地点]
如有需要，还可以添加：
D. [其他问题的答案]
E. [其他问题的答案]
F. [其他问题的答案]

注意：如果原谜题中有在A/B/C之外的附加问题，请用D/E/F分别回答它们。"""

        # 构建完整的线索分析和结果
        suspect = solution_data.get("suspect", "未知")
        weapon = solution_data.get("weapon", "未知")
        location = solution_data.get("location", "未知")
        
        suspect_locations = solution_data.get("suspect_locations", {})
        weapon_locations = solution_data.get("weapon_locations", {})
        
        # 准备位置信息摘要
        locations_summary = ""
        for s, l in suspect_locations.items():
            locations_summary += f"- {s}位于{l}\n"
        for w, l in weapon_locations.items():
            locations_summary += f"- {w}位于{l}\n"
        
        solution_description = f"""
根据逻辑分析，我得到以下结论：

1. 凶手：{suspect}
2. 凶器：{weapon}
3. 案发地点：{location}

各实体位置信息：
{locations_summary}

请根据原始谜题的要求，给出格式化的最终答案。确保检查原题是否有要求回答其他问题（如嫌疑人位置、物品位置等）。
"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"原始谜题：\n\n{prompt}\n\n分析结果：\n\n{solution_description}"}
        ]
        
        api_response = await self.call_api(messages)
        
        if not api_response.get("success", False):
            return {
                "success": False,
                "error": api_response.get("error", "API调用失败"),
                "answer": f"A. {suspect}\nB. {weapon}\nC. {location}"  # 默认答案
            }
        
        # 处理响应
        try:
            response_data = api_response["data"]
            assistant_message = response_data["choices"][0]["message"]
            content = assistant_message.get("content", "")
            
            return {
                "success": True,
                "answer": content
            }
        except Exception as e:
            logger.error(f"处理最终答案时出错: {str(e)}")
            return {
                "success": False,
                "error": f"处理最终答案时出错: {str(e)}",
                "answer": f"A. {suspect}\nB. {weapon}\nC. {location}"  # 默认答案
            }
    
    async def solve_puzzle(self, puzzle_text: str, expected_solution: Dict = None) -> Dict:
        """按照管道流程处理谜题"""
        start_time = time.time()
    
        try:
            # 步骤1：初步处理
            logger.info("步骤1：初步API处理")
            initial_result = await self.process_initial_prompt(puzzle_text)
            
            if not initial_result.get("success", False):
                logger.warning(f"初步处理失败: {initial_result.get('error', '未知错误')}")
                # 如果初步处理失败，尝试直接使用工具函数提取
                raw_entities_result = LogicUtils.extract_entities(puzzle_text)
                clues_result = LogicUtils.extract_clues(puzzle_text)
                
                initial_data = {
                    "suspects": raw_entities_result.get("suspects", []),
                    "weapons": raw_entities_result.get("weapons", []),
                    "locations": raw_entities_result.get("locations", []),
                    "clues": clues_result.get("clues", [])
                }
            else:
                initial_data = initial_result.get("initial_data", {})
            
            # 保存初步处理结果
            puzzle_id = f"puzzle_{hash(puzzle_text) % 10000:04d}"
            initial_file = f"{INTERIM_DIR}/{puzzle_id}_initial.json"
            with open(initial_file, 'w', encoding='utf-8') as f:
                json.dump(initial_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"初步处理结果已保存到 {initial_file}")
            
            # 新增步骤：使用GLM-4-Flash清理实体
            raw_entities = {
                "suspects": initial_data.get("suspects", []),
                "weapons": initial_data.get("weapons", []),
                "locations": initial_data.get("locations", [])
            }
            
            if self.entity_cleaner:
                logger.info("步骤1.5: 使用GLM-4-Flash清理实体")
                cleaned_entities = await self.entity_cleaner.clean_entities(puzzle_text, raw_entities)
                entities = cleaned_entities
                
                # 保存清理后的实体
                cleaned_file = f"{INTERIM_DIR}/{puzzle_id}_cleaned_entities.json"
                with open(cleaned_file, 'w', encoding='utf-8') as f:
                    json.dump(entities, f, ensure_ascii=False, indent=2)
                
                logger.info(f"清理后的实体已保存到 {cleaned_file}")
            else:
                entities = raw_entities
        
            
            # 步骤2：使用工具函数提取线索（确保数据的完整性）
            logger.info("步骤2：工具函数提取线索")
            clues = initial_data.get("clues", [])
            
            # 如果API提取的实体或线索为空，使用工具函数提取
            if not clues:
                clues = LogicUtils.extract_clues(puzzle_text).get("clues", [])
            
            # 保存提取结果
            entities_file = f"{INTERIM_DIR}/{puzzle_id}_entities.json"
            with open(entities_file, 'w', encoding='utf-8') as f:
                json.dump(entities, f, ensure_ascii=False, indent=2)
            
            clues_file = f"{INTERIM_DIR}/{puzzle_id}_clues.json"
            with open(clues_file, 'w', encoding='utf-8') as f:
                json.dump({"clues": clues}, f, ensure_ascii=False, indent=2)
            
            logger.info(f"实体和线索已保存到 {entities_file} 和 {clues_file}")
            
            # 步骤3：分析每条线索，提取约束
            logger.info("步骤3：约束分析")
            constraints = []
            for clue in clues:
                constraint = LogicUtils.analyze_constraint(clue, entities)
                if constraint.get("success", False):
                    constraints.append(constraint)
            
            # 保存约束分析结果
            constraints_file = f"{INTERIM_DIR}/{puzzle_id}_constraints.json"
            with open(constraints_file, 'w', encoding='utf-8') as f:
                json.dump({"constraints": constraints}, f, ensure_ascii=False, indent=2)
            
            logger.info(f"约束分析结果已保存到 {constraints_file}")
            
            # 步骤4：使用CP-SAT求解器解决谜题
            logger.info("步骤4：CP-SAT求解")
            solution = LogicUtils.solve_with_cp_sat(entities, constraints)
            
            # 保存求解结果
            solution_file = f"{PROCESSED_DIR}/{puzzle_id}_solution.json"
            with open(solution_file, 'w', encoding='utf-8') as f:
                json.dump(solution, f, ensure_ascii=False, indent=2)
            
            logger.info(f"求解结果已保存到 {solution_file}")
            
            # 步骤5：生成最终答案
            logger.info("步骤5：生成最终答案")
            answer_result = await self.generate_final_answer(puzzle_text, solution)
            
            if not answer_result.get("success", False):
                logger.warning(f"生成最终答案失败: {answer_result.get('error', '未知错误')}")
            
            # 评估答案
            answer = answer_result.get("answer", "")
            accuracy = 0.0
            
            if expected_solution:
                accuracy = self._evaluate_answer(answer, expected_solution)
            
            # 构建最终结果
            final_result = {
                "success": True,
                "answer": answer,
                "accuracy": accuracy,
                "entities": entities,
                "clues": clues,
                "constraints": constraints,
                "solution": solution,
                "prompt": puzzle_text,
                "latency": time.time() - start_time,
                "tool_calls_count": len(clues) + len(constraints) + 1  # 统计工具调用次数
            }
            
            # 保存最终结果
            final_file = f"{PROCESSED_DIR}/{puzzle_id}_final.json"
            with open(final_file, 'w', encoding='utf-8') as f:
                json.dump(final_result, f, ensure_ascii=False, indent=2)
            
            logger.info(f"最终结果已保存到 {final_file}")
            
            return final_result
            
        except Exception as e:
            error_msg = f"处理谜题时出错: {str(e)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            
            return {
                "success": False,
                "error": error_msg,
                "answer": "A. 未知\nB. 未知\nC. 未知",
                "accuracy": 0.0,
                "prompt": puzzle_text,
                "latency": time.time() - start_time,
                "tool_calls_count": 0
            }
    
    def _evaluate_answer(self, answer: str, solution: Dict) -> float:
        """评估答案准确度"""
        try:
            correct_count = 0
            total_items = len(solution)
            
            # 提取答案项
            for key, expected in solution.items():
                pattern = rf"{key}\.\s*([^\n]+)"
                match = re.search(pattern, answer)
                if match and match.group(1).strip().lower() == expected.lower():
                    correct_count += 1
            
            return correct_count / total_items if total_items > 0 else 0
        except Exception as e:
            logger.error(f"评估答案时出错: {str(e)}")
            return 0.0
    
    async def process_batch(self, puzzles: List[Dict], semaphore: asyncio.Semaphore, pbar: tqdm) -> List[Dict]:
        """处理一批谜题"""
        results = []
        
        async def process_one(puzzle: Dict):
            async with semaphore:
                try:
                    prompt = puzzle.get("prompt", "")
                    solution = puzzle.get("solution", {})
                    
                    result = await self.solve_puzzle(prompt, solution)
                    result["solution_reference"] = solution  # 添加参考解答
                    
                    return result
                except Exception as e:
                    logger.error(f"处理谜题时出错: {str(e)}")
                    return {
                        "success": False,
                        "error": str(e),
                        "prompt": prompt,
                        "solution_reference": solution,
                        "accuracy": 0.0,
                        "tool_calls_count": 0
                    }
                finally:
                    pbar.update(1)
        
        # 并行处理所有谜题
        tasks = [process_one(puzzle) for puzzle in puzzles]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 处理结果
        for result in batch_results:
            if isinstance(result, Exception):
                logger.error(f"批处理出错: {str(result)}")
                results.append({
                    "success": False,
                    "error": str(result),
                    "accuracy": 0.0,
                    "tool_calls_count": 0
                })
            else:
                results.append(result)
        
        return results
    
    async def process_puzzles(self, puzzles: List[Dict], max_concurrent: int = 3) -> List[Dict]:
        """并行处理多个谜题"""
        all_results = []
        
        # 创建信号量控制并发
        semaphore = asyncio.Semaphore(max_concurrent)
        
        # 使用进度条
        with tqdm(total=len(puzzles), desc="处理谜题") as pbar:
            batch_size = 10  # 每次处理10个谜题
            
            for i in range(0, len(puzzles), batch_size):
                batch = puzzles[i:i+batch_size]
                batch_results = await self.process_batch(batch, semaphore, pbar)
                all_results.extend(batch_results)
        
        # 关闭会话
        await self.close_session()
        
        return all_results

async def run_pipeline(
    input_file: str,
    output_file: str,
    api_token: str,
    glm4_token: str,
    api_url: str,
    model: str,
    batch_size: int = 0,
    max_concurrent: int = 3
):
    """运行管道处理"""
    start_time = time.time()
    
    # 加载测试数据
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            test_data = json.load(f)
    except FileNotFoundError:
        logger.error(f"输入文件不存在: {input_file}")
        return
    except json.JSONDecodeError:
        logger.error(f"输入文件JSON格式错误: {input_file}")
        return
    
    # 处理不同的输入格式
    if isinstance(test_data, dict) and "results" in test_data:
        items_to_process = test_data["results"]
    elif isinstance(test_data, list):
        items_to_process = test_data
    else:
        logger.error("不支持的输入文件格式")
        return
    
    # 限制处理数量
    if batch_size > 0:
        items_to_process = items_to_process[:batch_size]
    
    total_items = len(items_to_process)
    logger.info(f"将处理 {total_items} 个谜题")
    
    # 创建求解器
    solver = PipelineSolver(api_token, api_url, model, glm4_token)
    
    # 处理所有谜题
    results = await solver.process_puzzles(items_to_process, max_concurrent)
    
    # 统计结果
    successful_count = sum(1 for r in results if r.get("success", False))
    accuracy_sum = sum(r.get("accuracy", 0) for r in results if r.get("success", False))
    total_latency = sum(r.get("latency", 0) for r in results)
    total_tool_calls = sum(r.get("tool_calls_count", 0) for r in results)
    print("\nsuccessful_sum:",successful_count,"\naccuracy_sum:", accuracy_sum)
    # 计算平均值
    avg_accuracy = accuracy_sum / successful_count if successful_count > 0 else 0
    avg_latency = total_latency / total_items if total_items > 0 else 0
    avg_tool_calls = total_tool_calls / successful_count if successful_count > 0 else 0
    
    # 创建结果报告
    report = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "model": model,
        "total_items": total_items,
        "successful_items": successful_count,
        "success_rate": successful_count / total_items if total_items > 0 else 0,
        "average_accuracy": avg_accuracy,
        "total_latency": total_latency,
        "average_latency": avg_latency,
        "total_tool_calls": total_tool_calls,
        "average_tool_calls": avg_tool_calls,
        "results": results
    }
    
    # 保存结果
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"{RESULTS_DIR}/pipeline_results_{timestamp}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        # 简化输出
        simplified_results = []
        for result in results:
            simplified = {
                "prompt": result.get("prompt", ""),
                "solution_reference": result.get("solution_reference", {}),
                "answer": result.get("answer", ""),
                "accuracy": result.get("accuracy", 0),
                "success": result.get("success", False),
                "tool_calls_count": result.get("tool_calls_count", 0),
                "latency": result.get("latency", 0),
                "error": result.get("error", "")
            }
            simplified_results.append(simplified)
            
        simplified_report = report.copy()
        simplified_report["results"] = simplified_results
        json.dump(simplified_report, f, ensure_ascii=False, indent=2)
    
    # 打印结果摘要
    total_duration = time.time() - start_time
    logger.info(f"处理完成，总耗时: {total_duration:.2f}秒")
    print("\n===== 结果摘要 =====")
    print(f"总谜题数: {total_items}")
    print(f"成功处理: {successful_count} ({successful_count / total_items * 100:.2f}%)")
    print(f"平均准确率: {avg_accuracy * 100:.2f}%")
    print(f"平均工具调用: {avg_tool_calls:.2f}次/谜题")
    print(f"总耗时: {total_duration:.2f}秒 (平均{total_duration / total_items:.2f}秒/谜题)")
    print(f"结果已保存至: {output_file}")

def main():
    parser = argparse.ArgumentParser(description="管道式逻辑谜题求解器")
    parser.add_argument("--model", type=str, default="glm-z1-flash",
                       choices=["glm-z1-air", "glm-z1-airx", "glm-z1-flash"],
                       help="使用的模型名称")
    parser.add_argument("--api-token", type=str, 
                       default="cb8a1ca3f10b4c53b1eb48658941cd7e.OheueJjqF7PtK4yW",
                       help="API访问令牌")
    parser.add_argument("--api-url", type=str,
                       default="https://open.bigmodel.cn/api/paas/v4/chat/completions",
                       help="API基础URL")
    parser.add_argument("--glm4-token", type=str, 
                      default="75a6f84cc11344f88c6e4cff9962599f.JVgcBwlAAHsPwJkN",
                      help="GLM-4-Flash API令牌（用于实体清理)")
    parser.add_argument("--input-file", type=str, default="data/tc_200_zh.json",
                       help="输入谜题文件路径")
    parser.add_argument("--output-file", type=str, default="",
                       help="输出结果文件路径")
    parser.add_argument("--batch-size", type=int, default=0,
                       help="要处理的谜题总数量（0表示全部）")
    parser.add_argument("--concurrent", type=int, default=30,
                       help="最大并行处理数量")
    
    args = parser.parse_args()
    
    # 运行求解器
    asyncio.run(
        run_pipeline(
            input_file=args.input_file,
            output_file=args.output_file,
            api_token=args.api_token,
            glm4_token=args.glm4_token,
            api_url=args.api_url,
            model=args.model,
            batch_size=args.batch_size,
            max_concurrent=args.concurrent
        )
    )

if __name__ == "__main__":
    main()